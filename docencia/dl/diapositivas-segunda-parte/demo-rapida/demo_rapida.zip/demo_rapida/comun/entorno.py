"""Arranque portable de la demo: Windows, macOS y Linux, con o sin nada instalado.

Este módulo es lo primero que ejecuta cada cuaderno y lo único que no puede
dar nada por supuesto: se escribe con la biblioteca estándar, sin importar
torch ni numpy, porque cuando corre puede que todavía no estén instalados.

Hace tres cosas:

    instalar()          pone las dependencias que falten, con los argumentos
                        de pip que corresponden a este sistema operativo
    preparar()          deja el proceso listo: `comun` importable, el
                        directorio de trabajo en la raíz de la demo y las
                        variables de entorno que evitan avisos inútiles
    comando_servidor()  argv del servidor MCP, con UTF-8 forzado en el hijo

Las dos primeras se llaman desde las primeras celdas de los seis cuadernos.
"""

from __future__ import annotations

import importlib
import importlib.metadata as md
import os
import platform
import re
import shutil
import subprocess
import sys
from pathlib import Path

# --------------------------------------------------------------------------
# Qué versiones. Suelo y techo en todo.
# --------------------------------------------------------------------------
#
# El suelo es la versión más antigua con la que la demo funciona. El techo es
# la primera major que no se ha probado: sin él, pip instala hoy transformers
# 5.x, que cambia la API, y el alumno se encuentra un error que no es suyo.
#
# `dtype=` en `from_pretrained` sustituyó a `torch_dtype=` en transformers
# 4.56. Los cuadernos usan la forma nueva, así que ese es el suelo real.

PAQUETES: list[tuple[str, str, str]] = [
    # (nombre en pip, versión mínima, primera versión excluida)
    ("numpy", "1.24", "3"),
    ("transformers", "4.56", "5"),
    ("sentence-transformers", "3.0", "6"),
    ("peft", "0.11", "1"),
    ("accelerate", "0.30", "2"),
    ("scikit-learn", "1.3", "2"),
    ("matplotlib", "3.7", "4"),
    ("huggingface_hub", "0.30", "1"),
]

TORCH_MIN, TORCH_MAX = "2.4", "3"

# La última versión de PyTorch con ruedas para macOS sobre Intel. De la 2.3 en
# adelante solo se publican para Apple Silicon, así que un Mac Intel se queda
# aquí. Comprobado contra PyPI, no de memoria: `notebooks_build/comprobar_ruedas.py`.
TORCH_MAC_INTEL = "2.2.2"

FAISS_MIN, FAISS_MAX = "1.8", "2"

# Índice de ruedas de PyTorch sin CUDA. En Linux, `pip install torch` a secas
# baja el build con CUDA: 555 MB de torch más los paquetes `nvidia-*`, cerca de
# 3 GB en total, inútiles en un portátil sin GPU. Por este índice son ~200 MB.
INDICE_CPU = "https://download.pytorch.org/whl/cpu"

PY_MIN = (3, 10)
PY_MAX_PROBADO = (3, 13)


# --------------------------------------------------------------------------
# Dónde está la demo
# --------------------------------------------------------------------------

def raiz() -> Path:
    """Carpeta `demo_rapida/`, deducida de la posición de este fichero.

    No depende del directorio de trabajo, que cambia según quién lance el
    cuaderno: Jupyter lo pone en la carpeta del .ipynb, VS Code puede ponerlo
    en la raíz del espacio de trabajo y Colab en `/content`.
    """
    return Path(__file__).resolve().parent.parent


def preparar(verboso: bool = False) -> Path:
    """Deja el proceso listo para ejecutar el resto del cuaderno.

    Mete la raíz de la demo en `sys.path` (para `import comun`), se sitúa en
    ella (para las rutas relativas `figs/`, `mcp_demo/` y `modelos/`) y fija
    las variables de entorno que hacen falta en Windows. En silencio: el
    alumno no tiene por qué enterarse de nada de esto.

    Returns:
        la raíz de la demo.
    """
    base = raiz()
    if str(base) not in sys.path:
        sys.path.insert(0, str(base))

    cambiado = Path.cwd().resolve() != base
    if cambiado:
        os.chdir(base)

    # Los tokenizadores de Hugging Face avisan de un fork que no hacemos.
    os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
    # Sin privilegios de administrador, Windows no crea enlaces simbólicos, y
    # la caché de modelos avisa de ello en cada descarga. Funciona igual:
    # copia los ficheros en vez de enlazarlos, a costa de algo más de disco.
    if es_windows():
        os.environ.setdefault("HF_HUB_DISABLE_SYMLINKS_WARNING", "1")

    if verboso:
        print(f"Carpeta de trabajo: {base}")
        if cambiado:
            print("   (me he movido ahí para que las rutas relativas funcionen)")
    return base


# --------------------------------------------------------------------------
# Sistema
# --------------------------------------------------------------------------

def es_windows() -> bool:
    return sys.platform.startswith("win")


def es_mac() -> bool:
    return sys.platform == "darwin"


def es_mac_intel() -> bool:
    """Mac con procesador Intel, que es donde PyTorch se quedó en la 2.2.2."""
    return es_mac() and platform.machine() in ("x86_64", "i386")


def en_colab() -> bool:
    return "google.colab" in sys.modules or "COLAB_RELEASE_TAG" in os.environ


def hay_nvidia() -> bool:
    """¿Hay una tarjeta NVIDIA con driver instalado?

    Se mira si existe `nvidia-smi` y no `torch.cuda`, porque esto corre antes
    de que PyTorch exista. Es solo informativo: tener la tarjeta no basta para
    que la versión con CUDA funcione, porque el driver puede ser más antiguo
    que la versión de CUDA contra la que se compiló PyTorch.
    """
    return shutil.which("nvidia-smi") is not None


def quiere_gpu() -> bool:
    """¿El usuario ha pedido explícitamente la versión con CUDA?

    La demo está pensada para CPU y los seis cuadernos terminan en menos de
    una hora sin GPU. Instalar la versión con CUDA por defecto costaría unos
    3 GB de descarga y añadiría un modo de fallo que en un aula no compensa:
    si el driver de la máquina es más antiguo que el CUDA del paquete,
    PyTorch avisa con un muro de texto y se cae a CPU de todas formas.

    Quien quiera usar su GPU arranca Jupyter con DEMO_GPU=1.
    """
    return os.environ.get("DEMO_GPU", "").strip().lower() in ("1", "true", "si", "sí")


def info_sistema() -> dict[str, str]:
    """Lo que hay que saber del sistema antes de instalar nada."""
    return {
        "sistema": platform.system(),
        "version_so": platform.release(),
        "maquina": platform.machine(),
        "python": platform.python_version(),
        "ejecutable": sys.executable,
        "colab": "sí" if en_colab() else "no",
        "nvidia-smi": "sí" if hay_nvidia() else "no",
        "gpu_pedida": "sí" if quiere_gpu() else "no",
    }


# --------------------------------------------------------------------------
# Comparación de versiones
# --------------------------------------------------------------------------

def _tupla(version: str) -> tuple[int, ...]:
    """'2.9.1+cpu' -> (2, 9, 1). Suficiente para comparar suelo y techo."""
    partes: list[int] = []
    for trozo in re.split(r"[.+_-]", version)[:3]:
        encontrado = re.match(r"\d+", trozo)
        partes.append(int(encontrado.group()) if encontrado else 0)
    while len(partes) < 3:
        partes.append(0)
    return tuple(partes)


def _en_rango(version: str, minimo: str, maximo: str) -> bool:
    return _tupla(minimo) <= _tupla(version) < _tupla(maximo)


def instalada(paquete: str) -> str | None:
    """Versión instalada de `paquete`, o None si no está."""
    try:
        return md.version(paquete)
    except md.PackageNotFoundError:
        return None


def _falta(paquete: str, minimo: str, maximo: str) -> bool:
    """True si hay que llamar a pip por este paquete."""
    v = instalada(paquete)
    return v is None or not _en_rango(v, minimo, maximo)


# --------------------------------------------------------------------------
# El plan de instalación
# --------------------------------------------------------------------------

def plan_instalacion(
    *,
    windows: bool,
    mac: bool,
    mac_intel: bool,
    colab: bool,
    gpu: bool,
    version_python: tuple[int, int],
    presentes: dict[str, str],
) -> list[dict]:
    """Qué órdenes de pip hay que ejecutar en este sistema.

    Función pura: no mira el sistema de verdad ni ejecuta nada. Recibe la
    descripción de la máquina y devuelve la lista de órdenes. Así las ramas
    de Windows y de Mac se pueden probar desde Linux, que es lo que hace
    `notebooks_build/test_entorno.py`.

    Args:
        windows, mac, mac_intel, colab: rasgos del sistema.
        gpu: si el usuario ha pedido la versión con CUDA (DEMO_GPU=1).
        version_python: (mayor, menor) del intérprete que ejecutará la demo.
        presentes: versiones ya instaladas, {nombre_pip: version}.

    Returns:
        lista de órdenes, cada una {"etiqueta", "args", "obligatoria"}, donde
        `args` son los argumentos de `pip install`. Lista vacía si no falta
        nada.
    """
    def ausente(nombre: str, minimo: str, maximo: str) -> bool:
        v = presentes.get(nombre)
        return v is None or not _en_rango(v, minimo, maximo)

    ordenes: list[dict] = []

    # --- PyTorch, que es el único cuya rueda depende de la máquina ---------
    if ausente("torch", TORCH_MIN, TORCH_MAX) or (mac_intel and "torch" not in presentes):
        if colab:
            # Colab trae PyTorch con CUDA preinstalado y reinstalarlo rompe
            # la sesión con más frecuencia que la arregla.
            pass
        elif mac_intel:
            # Techo infranqueable: no existen ruedas de torch >= 2.3 para
            # macOS sobre Intel. Y la 2.2.2 solo llega hasta Python 3.11.
            ordenes.append({
                "etiqueta": f"PyTorch {TORCH_MAC_INTEL} (último que publica rueda para Mac Intel)",
                "args": [f"torch=={TORCH_MAC_INTEL}"],
                "obligatoria": True,
            })
        elif mac:
            ordenes.append({
                "etiqueta": "PyTorch (Apple Silicon)",
                "args": [f"torch>={TORCH_MIN},<{TORCH_MAX}"],
                "obligatoria": True,
            })
        elif gpu:
            ordenes.append({
                "etiqueta": "PyTorch con CUDA (lo has pedido con DEMO_GPU=1)",
                "args": [f"torch>={TORCH_MIN},<{TORCH_MAX}"],
                "obligatoria": True,
            })
        else:
            ordenes.append({
                "etiqueta": "PyTorch para CPU (~200 MB en vez de ~3 GB)",
                "args": [f"torch>={TORCH_MIN},<{TORCH_MAX}",
                         "--index-url", INDICE_CPU],
                "obligatoria": True,
            })

    # --- El resto, iguales en los tres sistemas ---------------------------
    pendientes = [f"{n}>={mi},<{ma}" for n, mi, ma in PAQUETES if ausente(n, mi, ma)]
    if pendientes:
        ordenes.append({
            "etiqueta": "transformers, sentence-transformers, peft y compañía",
            "args": pendientes,
            "obligatoria": True,
        })

    # --- FAISS, opcional --------------------------------------------------
    #
    # Las ruedas de macOS exigen un sistema reciente (14+ en Apple Silicon,
    # 15+ en Intel). En un Mac más viejo no hay rueda, pip intentaría
    # compilar desde fuente y fallaría media hora después. `--only-binary`
    # corta eso en seco, y el cuaderno 01 sigue funcionando con numpy.
    if ausente("faiss-cpu", FAISS_MIN, FAISS_MAX):
        ordenes.append({
            "etiqueta": "FAISS (opcional: si no hay rueda para tu sistema, se usa numpy)",
            "args": [f"faiss-cpu>={FAISS_MIN},<{FAISS_MAX}", "--only-binary=:all:"],
            "obligatoria": False,
        })

    return ordenes


def avisos_version_python(version_python: tuple[int, int], mac_intel: bool) -> list[str]:
    """Problemas conocidos de esta versión de Python. Lista vacía si no hay."""
    avisos = []
    if version_python < PY_MIN:
        avisos.append(
            f"Python {version_python[0]}.{version_python[1]} es demasiado antiguo. "
            f"La demo necesita {PY_MIN[0]}.{PY_MIN[1]} o posterior.")
    if version_python > PY_MAX_PROBADO:
        avisos.append(
            f"Python {version_python[0]}.{version_python[1]} es más nuevo que el "
            f"último probado ({PY_MAX_PROBADO[0]}.{PY_MAX_PROBADO[1]}). Puede que "
            "alguna rueda todavía no exista para él.")
    if mac_intel and version_python > (3, 11):
        avisos.append(
            f"En un Mac con Intel, PyTorch {TORCH_MAC_INTEL} es el último "
            "disponible y solo tiene ruedas hasta Python 3.11. Instala Python "
            "3.11 o usa Google Colab.")
    return avisos


# --------------------------------------------------------------------------
# Ejecutar el plan
# --------------------------------------------------------------------------

def instalar(verboso: bool = False) -> None:
    """Instala lo que falte. No hace nada si ya está todo.

    Mira primero qué sistema operativo hay y qué versiones están ya
    instaladas; solo entonces, y solo para lo que falte, llama a pip. Se
    puede ejecutar tantas veces como se quiera.

    De cara al alumno imprime dos líneas. Todo el detalle (qué índice de
    ruedas, qué versión de cada paquete, la salida de pip) aparece con
    `instalar(verboso=True)`, que es lo que hay que ejecutar cuando algo
    falla.

    Args:
        verboso: si es True, enseña el plan completo y la salida de pip.
    """
    sistema = info_sistema()
    cabecera = (f"{sistema['sistema']} {sistema['version_so']} · "
                f"Python {sistema['python']}")
    if verboso:
        print(f"Sistema    : {sistema['sistema']} {sistema['version_so']} "
              f"({sistema['maquina']})")
        print(f"Python     : {sistema['python']}")
        print(f"Intérprete : {sistema['ejecutable']}")
        print(f"Colab      : {sistema['colab']}   ·   nvidia-smi: "
              f"{sistema['nvidia-smi']}   ·   DEMO_GPU: {sistema['gpu_pedida']}")

    version_python = sys.version_info[:2]
    for aviso in avisos_version_python(version_python, es_mac_intel()):
        print(f"AVISO: {aviso}\n")

    presentes = {n: v for n, v in
                 ((p, instalada(p)) for p in
                  ["torch", "faiss-cpu", *(n for n, _, _ in PAQUETES)])
                 if v is not None}

    ordenes = plan_instalacion(
        windows=es_windows(), mac=es_mac(), mac_intel=es_mac_intel(),
        colab=en_colab(), gpu=quiere_gpu(),
        version_python=version_python, presentes=presentes)

    if not ordenes:
        print(f"Entorno listo, no hay nada que instalar.  ({cabecera})")
        if verboso:
            _resumen_versiones()
        return

    print(f"Preparando el entorno. La primera vez tarda unos minutos.  ({cabecera})")

    perdidas = []
    for orden in ordenes:
        if verboso:
            print(f"  · {orden['etiqueta']}")
            print(f"    pip install {' '.join(orden['args'])}")
        completo = [sys.executable, "-m", "pip", "install",
                    "--disable-pip-version-check", *orden["args"]]
        if not verboso:
            completo.insert(4, "-q")
        resultado = subprocess.run(completo, text=True,
                                   capture_output=not verboso)
        if resultado.returncode == 0:
            continue
        if orden["obligatoria"]:
            print((resultado.stderr or "")[-2000:])
            raise RuntimeError(
                "No he podido instalar: " + " ".join(orden["args"]) +
                ".\nEjecuta esta celda otra vez como instalar(verboso=True) para "
                "ver la salida completa de pip y enséñasela al profesor.")
        perdidas.append(orden["etiqueta"])

    # El kernel de Jupyter ya estaba vivo cuando pip escribió los paquetes
    # nuevos; sin esto, el `import torch` de la celda siguiente puede no
    # encontrarlos y obligar a reiniciar el kernel.
    importlib.invalidate_caches()

    print("Entorno listo.")
    if perdidas:
        # FAISS es lo único opcional, y su ausencia no cambia ningún resultado.
        print("   (una pieza opcional no tiene versión para tu sistema; el "
              "cuaderno 01 la sustituye solo)")
    if verboso:
        _resumen_versiones()


def _resumen_versiones() -> None:
    """Imprime qué versión ha quedado de cada cosa."""
    print("\nVersiones instaladas:")
    for nombre in ["torch", "transformers", "sentence-transformers", "peft",
                   "accelerate", "numpy", "faiss-cpu"]:
        v = instalada(nombre)
        print(f"   {nombre:24s} {v if v else '(no está: se usará la alternativa)'}")


# --------------------------------------------------------------------------
# Subprocesos: el servidor MCP del cuaderno 02
# --------------------------------------------------------------------------

def entorno_hijo() -> dict[str, str]:
    """Variables de entorno para un proceso hijo que habla JSON por stdio.

    En Windows, un proceso Python escribe en la página ANSI del sistema
    (cp1252 en una instalación española) y no en UTF-8. El servidor MCP manda
    JSON con acentos, el cliente lo lee como UTF-8, y el byte 0xF3 de la «ó»
    de «comisión» no es UTF-8 válido: la sesión se cae con UnicodeDecodeError
    en la primera respuesta con tilde. Estas dos variables ponen UTF-8 en los
    dos extremos del tubo.
    """
    env = dict(os.environ)
    env["PYTHONUTF8"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"
    return env


def comando_servidor(script: str = "servidor_mcp.py") -> list[str]:
    """argv para lanzar un servidor de `mcp_demo/` desde cualquier sistema.

    Usa `sys.executable` (el intérprete que mueve el cuaderno, no un `python3`
    del PATH que en Windows no existe), ruta absoluta (el directorio de
    trabajo del hijo no tiene por qué ser el nuestro) y `-X utf8`.
    """
    destino = raiz() / "mcp_demo" / script
    if not destino.is_file():
        raise FileNotFoundError(f"No encuentro el servidor MCP en {destino}")
    return [sys.executable, "-X", "utf8", str(destino)]
