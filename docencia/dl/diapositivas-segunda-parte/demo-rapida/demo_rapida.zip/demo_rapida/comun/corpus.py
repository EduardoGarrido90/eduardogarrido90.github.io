"""Base documental de la demo: la normativa interna de Banco Iberia.

Banco Iberia no existe. Está inventado a propósito, y es lo que hace que la
demo de RAG sea honesta: ningún modelo del mundo ha visto estos documentos
durante su preentrenamiento, así que si acierta las cifras es porque las ha
leído de los fragmentos recuperados, no porque las recuerde.

Cada fragmento lleva su procedencia (`documento`, `seccion`, `fecha`). Esa
procedencia es la que luego se enseña al usuario como cita. Un RAG que no
puede citar de dónde sale la respuesta no vale para nada en producción.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Fragmento:
    """Una unidad recuperable del corpus.

    Atributos:
        id: identificador corto, el que se imprime en las citas.
        documento: nombre del documento del que sale.
        seccion: apartado dentro del documento.
        fecha: fecha de la versión vigente, en ISO.
        texto: el contenido en sí.
    """

    id: str
    documento: str
    seccion: str
    fecha: str
    texto: str

    @property
    def cita(self) -> str:
        return f"{self.documento}, {self.seccion} (v. {self.fecha})"


CORPUS: list[Fragmento] = [
    Fragmento(
        "HIP-01",
        "Manual de Riesgo Hipotecario",
        "1. Límites de concesión",
        "2026-01-15",
        "Banco Iberia concede préstamos hipotecarios hasta un 80 % del valor de "
        "tasación de la vivienda habitual y hasta un 65 % en segunda residencia. "
        "La cuota mensual resultante, sumada a cualquier otra deuda del "
        "solicitante, no podrá superar el 35 % de sus ingresos netos mensuales. "
        "Superar ese umbral exige autorización del Comité de Riesgos.",
    ),
    Fragmento(
        "HIP-02",
        "Manual de Riesgo Hipotecario",
        "2. Plazos y edad",
        "2026-01-15",
        "El plazo máximo de amortización es de 30 años. La suma de la edad del "
        "titular más el plazo solicitado no puede exceder de 75 años. Para "
        "titulares de más de 60 años se exige un seguro de vida vinculado con "
        "cobertura igual al capital pendiente.",
    ),
    Fragmento(
        "HIP-03",
        "Manual de Riesgo Hipotecario",
        "3. Tipos aplicables",
        "2026-01-15",
        "El tipo fijo de referencia para hipotecas a 30 años es del 3,10 % TAE "
        "para clientes con nómina domiciliada y del 3,65 % TAE sin vinculación. "
        "El tipo variable se referencia al euríbor a 12 meses más un diferencial "
        "de 0,89 puntos porcentuales, con revisión anual.",
    ),
    Fragmento(
        "TAR-01",
        "Catálogo de Productos Minoristas",
        "4. Tarjetas",
        "2026-02-01",
        "La tarjeta Iberia Clásica tiene una cuota anual de 36 euros, exenta si "
        "el cliente factura más de 3.000 euros al año con ella. La tarjeta "
        "Iberia Premium cuesta 180 euros anuales e incluye seguro de viaje con "
        "cobertura de hasta 500.000 euros y acceso a salas VIP.",
    ),
    Fragmento(
        "TAR-02",
        "Catálogo de Productos Minoristas",
        "5. Disposiciones en efectivo",
        "2026-02-01",
        "La retirada de efectivo en cajeros de la red propia es gratuita. En "
        "cajeros de otras entidades dentro de España se aplica una comisión de "
        "1,95 euros por operación. Fuera de la zona euro la comisión es del "
        "4,5 % del importe, con un mínimo de 3,50 euros.",
    ),
    Fragmento(
        "FRA-01",
        "Protocolo de Fraude y Disputas",
        "2. Plazos de reclamación",
        "2026-03-10",
        "El cliente dispone de 13 meses desde el cargo para reclamar una "
        "operación no autorizada. Banco Iberia debe abonar el importe "
        "provisionalmente en un plazo máximo de 10 días hábiles desde la "
        "notificación, salvo que existan indicios razonados de fraude por parte "
        "del propio cliente.",
    ),
    Fragmento(
        "FRA-02",
        "Protocolo de Fraude y Disputas",
        "3. Escalado",
        "2026-03-10",
        "Toda incidencia de fraude por importe superior a 3.000 euros se escala "
        "automáticamente al equipo de Investigación Financiera en menos de 4 "
        "horas. Por debajo de ese importe la resuelve el agente de primera línea "
        "con un objetivo de 48 horas.",
    ),
    Fragmento(
        "CUE-01",
        "Catálogo de Productos Minoristas",
        "1. Cuentas corrientes",
        "2026-02-01",
        "La Cuenta Iberia Nómina no tiene comisión de mantenimiento si se "
        "domicilia una nómina de al menos 700 euros mensuales o dos recibos "
        "periódicos. En caso contrario la comisión es de 60 euros al año, "
        "cobrados por trimestres vencidos.",
    ),
    Fragmento(
        "CUE-02",
        "Catálogo de Productos Minoristas",
        "2. Descubiertos",
        "2026-02-01",
        "Los descubiertos en cuenta devengan un interés nominal del 18 % anual, "
        "más una comisión de reclamación de posición deudora de 30 euros por "
        "descubierto, con un máximo de una comisión al mes.",
    ),
    Fragmento(
        "INV-01",
        "Política de Inversión Minorista",
        "3. Perfilado MiFID",
        "2026-01-30",
        "Antes de contratar cualquier producto de inversión, el cliente debe "
        "completar el test de idoneidad MiFID II. El perfil resultante (muy "
        "conservador, conservador, moderado, dinámico o agresivo) tiene una "
        "validez de 24 meses y determina qué productos se le pueden ofrecer.",
    ),
    Fragmento(
        "INV-02",
        "Política de Inversión Minorista",
        "4. Fondos indexados",
        "2026-01-30",
        "La gama Iberia Índice aplica una comisión de gestión del 0,32 % anual "
        "sobre el patrimonio, sin comisión de suscripción ni de reembolso. La "
        "inversión mínima inicial es de 500 euros y las aportaciones periódicas "
        "parten de 50 euros al mes.",
    ),
    Fragmento(
        "ATC-01",
        "Manual de Atención al Cliente",
        "1. Tono y trato",
        "2026-02-20",
        "Toda comunicación escrita con el cliente se redacta en español neutro, "
        "en segunda persona del singular y sin tecnicismos no explicados. La "
        "respuesta empieza reconociendo el problema, continúa con la acción "
        "concreta que el banco va a tomar y termina con un plazo. Nunca se "
        "cierra una comunicación sin dar un plazo.",
    ),
    Fragmento(
        "ATC-02",
        "Manual de Atención al Cliente",
        "2. Tiempos de respuesta",
        "2026-02-20",
        "El objetivo de primera respuesta es de 2 horas en chat, 24 horas en "
        "correo electrónico y 5 días hábiles en reclamación formal ante el "
        "Servicio de Atención al Cliente. El incumplimiento se reporta "
        "mensualmente al Comité de Conducta.",
    ),
    Fragmento(
        "LOP-01",
        "Política de Protección de Datos",
        "2. Derechos del interesado",
        "2026-01-08",
        "El cliente puede ejercer los derechos de acceso, rectificación, "
        "supresión, oposición, limitación y portabilidad escribiendo a "
        "dpo@bancoiberia.example. El plazo máximo de respuesta es de un mes, "
        "prorrogable por dos meses más en solicitudes complejas, siempre "
        "notificando la prórroga en el primer mes.",
    ),
    Fragmento(
        "LOP-02",
        "Política de Protección de Datos",
        "5. Modelos de lenguaje",
        "2026-01-08",
        "Queda prohibido enviar datos personales de clientes a servicios de "
        "inteligencia artificial alojados fuera del espacio económico europeo. "
        "Los modelos desplegados en la infraestructura propia del banco deben "
        "registrar cada consulta en el log de auditoría durante 5 años.",
    ),
    Fragmento(
        "HIP-04",
        "Manual de Riesgo Hipotecario",
        "6. Gastos de constitución",
        "2026-01-15",
        "Desde la entrada en vigor de la normativa vigente, Banco Iberia asume "
        "los gastos de notaría, registro, gestoría e impuesto de actos jurídicos "
        "documentados. El cliente solo paga la tasación, con un coste medio de "
        "350 euros, y la copia de la escritura si la solicita.",
    ),
]


# Preguntas de evaluación: la respuesta correcta está en el corpus y solo ahí.
# El campo `fuente` es la respuesta del profesor, usada para medir si el
# recuperador trae el fragmento bueno.
PREGUNTAS: list[tuple[str, str]] = [
    ("¿Cuánto puedo pedir como máximo para mi vivienda habitual?", "HIP-01"),
    ("¿Qué comisión tiene sacar dinero en un cajero de otro banco en España?", "TAR-02"),
    ("Me han hecho un cargo que no reconozco, ¿cuánto tiempo tengo para reclamar?", "FRA-01"),
    ("¿Qué coste tiene la gama de fondos indexados del banco?", "INV-02"),
    ("¿Puedo mandar datos de clientes a ChatGPT?", "LOP-02"),
    ("¿Quién paga la notaría al firmar la hipoteca?", "HIP-04"),
]


def como_texto() -> str:
    """El corpus entero concatenado, para la demo de 'meterlo todo en el prompt'."""
    return "\n\n".join(f"[{f.id}] {f.texto}" for f in CORPUS)
