"""Código compartido por los cuadernos de la demo rápida."""
