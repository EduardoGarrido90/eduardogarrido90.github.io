"""Fontanería compartida por los cuadernos 03 (SFT), 04 (LoRA) y 05 (RLHF).

Aquí vive lo que es idéntico en los tres y no aporta nada leerlo tres veces:
tokenizar un lote con la máscara de etiquetas, generar en batch y medir si la
ficha que sale tiene el formato que pedimos. El bucle de entrenamiento NO está
aquí: ese sí se escribe entero en cada cuaderno, porque es lo que hay que ver.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

import torch
from torch import Tensor

IGNORAR = -100  # el valor que la cross-entropy de PyTorch salta sin mirar


# --------------------------------------------------------------------------
# Tokenización con máscara
# --------------------------------------------------------------------------

def construir_lote(tok, ejemplos: list[dict[str, str]], instruccion: str,
                   ) -> tuple[Tensor, Tensor, Tensor]:
    """Convierte ejemplos (entrada, salida) en tensores listos para entrenar.

    Args:
        tok: tokenizador con chat template.
        ejemplos: lista de dicts con claves ``entrada`` y ``salida``.
        instruccion: mensaje de sistema, igual para todos los ejemplos.

    Returns:
        ``(input_ids, attention_mask, labels)``, los tres de forma
        ``(batch, longitud)``. En ``labels``, todas las posiciones del prompt
        y del relleno valen -100; solo las de la respuesta llevan el id real.
    """
    pad = tok.pad_token_id if tok.pad_token_id is not None else tok.eos_token_id
    secuencias, cortes = [], []
    for e in ejemplos:
        msgs = [{"role": "system", "content": instruccion},
                {"role": "user", "content": e["entrada"]}]
        prompt = tok.apply_chat_template(msgs, add_generation_prompt=True, tokenize=False)
        ids_prompt = tok(prompt, add_special_tokens=False).input_ids
        ids_resp = tok(e["salida"] + tok.eos_token, add_special_tokens=False).input_ids
        secuencias.append(ids_prompt + ids_resp)
        cortes.append(len(ids_prompt))

    largo = max(len(s) for s in secuencias)
    n = len(secuencias)
    input_ids = torch.full((n, largo), pad, dtype=torch.long)
    attention = torch.zeros((n, largo), dtype=torch.long)
    labels = torch.full((n, largo), IGNORAR, dtype=torch.long)
    for i, (seq, corte) in enumerate(zip(secuencias, cortes)):
        t = torch.tensor(seq, dtype=torch.long)
        input_ids[i, :len(seq)] = t
        attention[i, :len(seq)] = 1
        labels[i, corte:len(seq)] = t[corte:]

    assert input_ids.shape == attention.shape == labels.shape
    assert (labels != IGNORAR).any(), "ningún token supervisado: revisa el chat template"
    return input_ids, attention, labels


# --------------------------------------------------------------------------
# Generación
# --------------------------------------------------------------------------

@torch.no_grad()
def generar(mod, tok, ejemplos: list[dict[str, str]], instruccion: str,
            max_new_tokens: int = 40, batch: int = 8,
            temperatura: float | None = None) -> list[str]:
    """Genera la respuesta del modelo para cada ejemplo. Determinista por defecto.

    Se usa padding por la izquierda porque en generación el modelo continúa a
    partir del ÚLTIMO token de cada fila; si el relleno estuviera a la derecha,
    continuaría a partir de un token de relleno y saldría basura.
    """
    lado = tok.padding_side
    tok.padding_side = "left"
    if tok.pad_token_id is None:
        tok.pad_token = tok.eos_token
    salidas: list[str] = []
    modo_entreno = mod.training
    mod.eval()
    try:
        for i in range(0, len(ejemplos), batch):
            trozo = ejemplos[i:i + batch]
            prompts = [tok.apply_chat_template(
                [{"role": "system", "content": instruccion},
                 {"role": "user", "content": e["entrada"]}],
                add_generation_prompt=True, tokenize=False) for e in trozo]
            ent = tok(prompts, return_tensors="pt", padding=True, add_special_tokens=False)
            ent = {k: v.to(mod.device) for k, v in ent.items()}
            kw = dict(do_sample=False) if temperatura is None else dict(
                do_sample=True, temperature=temperatura, top_p=0.95)
            out = mod.generate(**ent, max_new_tokens=max_new_tokens,
                               pad_token_id=tok.pad_token_id, **kw)
            nuevos = out[:, ent["input_ids"].shape[1]:]
            salidas += [tok.decode(f, skip_special_tokens=True).strip() for f in nuevos]
    finally:
        tok.padding_side = lado
        mod.train(modo_entreno)
    return salidas


# --------------------------------------------------------------------------
# Log-probabilidad de una respuesta completa (la necesita DPO)
# --------------------------------------------------------------------------

def log_prob_respuesta(mod, input_ids: Tensor, attention: Tensor,
                       labels: Tensor) -> Tensor:
    """Suma de log p(token | anteriores) sobre los tokens de la respuesta.

    Args:
        input_ids, attention, labels: lo que devuelve `construir_lote`, de
            forma ``(batch, longitud)``. En `labels`, -100 marca lo que no
            cuenta (prompt y relleno).

    Returns:
        Tensor ``(batch,)`` con log pi(respuesta | prompt) para cada fila.
        Es una suma, no una media: DPO compara probabilidades de secuencias
        completas y dividir por la longitud cambiaría el objetivo.
    """
    logits = mod(input_ids=input_ids, attention_mask=attention).logits
    # El logit de la posición t predice el token t+1: hay que desplazar.
    logits = logits[:, :-1, :]
    objetivo = labels[:, 1:]
    mascara = objetivo != IGNORAR
    seguro = objetivo.masked_fill(~mascara, 0)
    logp = torch.log_softmax(logits.float(), dim=-1)
    por_token = logp.gather(-1, seguro.unsqueeze(-1)).squeeze(-1)
    total = (por_token * mascara).sum(dim=-1)
    assert total.shape == (input_ids.shape[0],)
    assert torch.isfinite(total).all(), "log-probabilidad no finita"
    return total


# --------------------------------------------------------------------------
# Métrica de la tarea de triaje
# --------------------------------------------------------------------------

_CAMPOS = ("CATEGORIA", "URGENCIA", "EQUIPO", "SLA_HORAS")


@dataclass
class Metricas:
    """Tres niveles de exigencia sobre la misma salida.

    Atributos:
        formato: fracción de salidas con los cuatro campos presentes.
        categoria: fracción con la categoría correcta.
        exacto: fracción que coincide campo a campo con la ficha esperada.
    """

    formato: float
    categoria: float
    exacto: float
    n: int

    def __str__(self) -> str:
        return (f"formato {self.formato:6.1%}   categoría {self.categoria:6.1%}   "
                f"ficha exacta {self.exacto:6.1%}   (n={self.n})")


def parsear_ficha(texto: str) -> dict[str, str]:
    """Extrae los cuatro campos de una ficha. Devuelve solo los que encuentra."""
    campos: dict[str, str] = {}
    for campo in _CAMPOS:
        m = re.search(rf"^{campo}\s*:\s*(.+?)\s*$", texto, re.MULTILINE)
        if m:
            campos[campo] = m.group(1).strip().lower()
    return campos


def medir(predicciones: list[str], ejemplos: list[dict[str, str]]) -> Metricas:
    """Compara lo generado con la ficha de referencia de cada ejemplo."""
    assert len(predicciones) == len(ejemplos)
    ok_formato = ok_cat = ok_exacto = 0
    for pred, ej in zip(predicciones, ejemplos):
        p, g = parsear_ficha(pred), parsear_ficha(ej["salida"])
        if len(p) == len(_CAMPOS):
            ok_formato += 1
        if p.get("CATEGORIA") == g.get("CATEGORIA"):
            ok_cat += 1
        if p == g:
            ok_exacto += 1
    n = len(ejemplos)
    return Metricas(ok_formato / n, ok_cat / n, ok_exacto / n, n)
