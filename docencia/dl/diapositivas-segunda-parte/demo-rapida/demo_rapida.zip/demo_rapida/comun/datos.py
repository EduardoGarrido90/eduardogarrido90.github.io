"""Los dos conjuntos de datos que se entrenan en los cuadernos 03, 04 y 05.

Ambos giran alrededor del mismo escenario: el buzón de incidencias de Banco
Iberia. Lo que cambia es qué le pedimos al modelo.

    triaje()        -> pares (incidencia, ficha de CRM).  Se usa en SFT y LoRA.
    preferencias()  -> tríos (incidencia, respuesta buena, respuesta mala).
                       Se usa en RLHF.

Los datos están generados a partir de plantillas con una semilla fija. Es una
decisión consciente: un corpus real tendría ruido de etiquetado y la demo
tardaría horas en enseñar algo. Aquí la señal es limpia y el modelo aprende en
minutos de CPU, que es lo que necesitamos para ver el efecto en clase.
"""

from __future__ import annotations

import random

# --------------------------------------------------------------------------
# Tarea 1: triaje. Texto libre del cliente -> ficha estructurada del CRM.
# --------------------------------------------------------------------------

INSTRUCCION_TRIAJE = (
    "Eres el clasificador de incidencias de Banco Iberia. Devuelve exactamente "
    "cuatro líneas con este formato y nada más:\n"
    "CATEGORIA: <fraude|hipoteca|tarjeta|cuenta|inversion>\n"
    "URGENCIA: <alta|media|baja>\n"
    "EQUIPO: <investigacion|riesgos|operaciones|asesoria>\n"
    "SLA_HORAS: <numero>"
)

# categoria -> (urgencia, equipo, sla, [plantillas de incidencia])
_TRIAJE: dict[str, tuple[str, str, int, list[str]]] = {
    "fraude": ("alta", "investigacion", 4, [
        "Me han hecho un cargo de {importe} euros en {sitio} y yo no he comprado nada ahí.",
        "Veo tres pagos seguidos a {sitio} por {importe} euros que no reconozco.",
        "Creo que me han clonado la tarjeta: aparece un cargo de {importe} euros de {sitio}.",
        "Me ha llegado un SMS pidiéndome las claves y después un cargo de {importe} euros.",
        "Alguien ha sacado {importe} euros de mi cuenta de madrugada, yo estaba durmiendo.",
        "Han intentado entrar en mi banca online desde un móvil que no es el mío.",
    ]),
    "hipoteca": ("media", "riesgos", 48, [
        "Quiero saber si me darían una hipoteca de {importe} euros con mi nómina.",
        "Estoy mirando un piso de {importe} euros, ¿cuánto me podéis financiar?",
        "¿Me podéis decir qué diferencial me aplicáis sobre el euríbor?",
        "Quiero pasar mi hipoteca de variable a fijo, ¿qué me costaría?",
        "Tengo {edad} años, ¿a cuántos años como máximo me podéis dar la hipoteca?",
        "He pedido una subrogación hace tres semanas y nadie me ha contestado.",
    ]),
    "tarjeta": ("media", "operaciones", 24, [
        "Me han cobrado {importe} euros de cuota anual de la tarjeta y no me lo esperaba.",
        "Mi tarjeta ha caducado y no me ha llegado la nueva.",
        "El cajero se ha quedado con mi tarjeta y no me la ha devuelto.",
        "Quiero subir el límite de la tarjeta a {importe} euros.",
        "Me cobran comisión al sacar dinero fuera de España, ¿eso es normal?",
        "Quiero cancelar la tarjeta Premium, no uso las salas VIP.",
    ]),
    "cuenta": ("baja", "operaciones", 48, [
        "Me han cobrado {importe} euros de mantenimiento y tengo la nómina domiciliada.",
        "Quiero cambiar la cuenta donde me ingresan la nómina.",
        "No consigo descargar el extracto del mes pasado desde la app.",
        "Me he quedado en descubierto {importe} euros y me han metido una comisión.",
        "Quiero añadir a mi pareja como titular de la cuenta.",
        "He cambiado de domicilio y quiero actualizar mis datos.",
    ]),
    "inversion": ("baja", "asesoria", 72, [
        "Quiero meter {importe} euros en fondos indexados, ¿cuál me recomendáis?",
        "Mi test MiFID ha caducado y la app no me deja contratar nada.",
        "¿Qué comisión de gestión tiene vuestra gama indexada?",
        "Quiero traspasar un fondo de otra entidad a Banco Iberia.",
        "Me sale perfil conservador y quiero cambiarlo a moderado.",
        "¿Cuánto es la aportación mínima mensual a un fondo?",
    ]),
}

_SITIOS = ["una web de criptomonedas", "una tienda de Bangkok", "una gasolinera de Murcia",
           "un portal de apuestas", "una app de viajes", "una tienda de electrónica online"]

# Importes verosímiles por categoría. Un piso de 38 euros destruye la demo:
# el alumno deja de leer el formato y se ríe del dato.
_IMPORTES: dict[str, list[int]] = {
    "fraude": [38, 60, 120, 240, 350, 900, 1500, 3200, 4800],
    "hipoteca": [120000, 150000, 185000, 210000, 240000, 310000],
    "tarjeta": [36, 90, 180, 600, 1200, 3000],
    "cuenta": [15, 30, 45, 60, 120, 240],
    "inversion": [500, 1000, 3000, 6000, 12000, 25000],
}


def _ficha(cat: str) -> str:
    urg, equipo, sla, _ = _TRIAJE[cat]
    return (f"CATEGORIA: {cat}\nURGENCIA: {urg}\nEQUIPO: {equipo}\nSLA_HORAS: {sla}")


def triaje(n_train: int = 160, n_test: int = 40, seed: int = 0
           ) -> tuple[list[dict[str, str]], list[dict[str, str]]]:
    """Genera el conjunto de triaje.

    Devuelve dos listas de diccionarios con claves ``entrada`` y ``salida``.
    El reparto entre train y test es estratificado por categoría y los textos
    no se repiten entre ambos: lo que el modelo ve en test es combinación nueva
    de plantilla e importe.
    """
    rng = random.Random(seed)
    ejemplos: list[dict[str, str]] = []
    cats = list(_TRIAJE)
    for i in range(n_train + n_test):
        cat = cats[i % len(cats)]
        plantilla = rng.choice(_TRIAJE[cat][3])
        texto = plantilla.format(
            importe=f"{rng.choice(_IMPORTES[cat]):,}".replace(",", "."),
            sitio=rng.choice(_SITIOS),
            edad=rng.choice([48, 52, 58, 61, 64]),
        )
        ejemplos.append({"entrada": texto, "salida": _ficha(cat), "categoria": cat})
    rng.shuffle(ejemplos)
    return ejemplos[:n_train], ejemplos[n_train:n_train + n_test]


# Conjunto escrito a mano, sin plantilla. Sirve para ver el hueco entre
# "el modelo ha aprendido la tarea" y "el modelo ha memorizado mis plantillas".
# Es la diferencia entre un número bonito y un número que te puedes creer.
_DIFICIL: list[tuple[str, str]] = [
    ("Buenas, resulta que ayer vi en el extracto un pago a una página rarísima "
     "que yo no he hecho en mi vida, y encima de 900 pavos.", "fraude"),
    ("Hola! estoy con mi pareja mirando pisos y queríamos saber hasta dónde "
     "llegaríamos con lo que ganamos entre los dos", "hipoteca"),
    ("llevo dos semanas sin tarjeta porque la que tenía caducó en marzo y la "
     "nueva no aparece por ningún lado", "tarjeta"),
    ("Me gustaría que me explicaseis por qué este trimestre me habéis quitado "
     "dinero de mantenimiento si yo cobro aquí todos los meses.", "cuenta"),
    ("Tengo unos ahorrillos parados y me han dicho que lo de los indexados "
     "está bien, ¿qué me contáis?", "inversion"),
    ("Buenos días. Un señor que dice ser del banco me llamó pidiéndome el "
     "código del móvil y ahora me falta dinero.", "fraude"),
    ("¿Hasta qué edad puedo estar pagando el préstamo de la casa?", "hipoteca"),
    ("Me acaba de tragar el cajero de la calle Alcalá la tarjeta y tengo que "
     "coger un vuelo esta tarde.", "tarjeta"),
    ("Quería poner también a mi hermana en la cuenta por si me pasa algo.", "cuenta"),
    ("La aplicación me dice que mi perfil de riesgo está caducado y no me deja "
     "comprar nada.", "inversion"),
    ("Alguien se ha metido en mi banca online desde un sitio raro, lo he visto "
     "en los avisos.", "fraude"),
    ("Querría dejar de pagar los 180 euros de la tarjeta esa buena que tengo, "
     "que no la uso.", "tarjeta"),
]


def triaje_dificil() -> list[dict[str, str]]:
    """Doce incidencias escritas a mano, con el fraseo torcido de un cliente real."""
    return [{"entrada": t, "salida": _ficha(c), "categoria": c} for t, c in _DIFICIL]


# --------------------------------------------------------------------------
# Tarea 2: preferencias. Dos respuestas al cliente, una mejor que la otra.
# --------------------------------------------------------------------------

INSTRUCCION_TONO = (
    "Eres el agente de atención al cliente de Banco Iberia. Responde al cliente "
    "en dos o tres frases: reconoce el problema, di qué vas a hacer y da un plazo. "
    "Tutea y no uses jerga."
)

# (incidencia, respuesta que cumple el manual ATC-01, respuesta que no)
_PREFS: list[tuple[str, str, str]] = [
    ("Me han cobrado 240 euros que no reconozco.",
     "Entiendo el susto. Bloqueo la tarjeta ahora mismo y abro una reclamación por ese cargo. Tendrás el importe devuelto provisionalmente en un máximo de 10 días hábiles.",
     "Le informamos de que su solicitud ha sido registrada en nuestros sistemas y será tramitada conforme a los procedimientos internos vigentes de la entidad."),
    ("Llevo tres semanas esperando respuesta a mi subrogación.",
     "Tienes razón, tres semanas es demasiado. Escalo tu expediente a Riesgos hoy mismo y te llamo con una respuesta antes del viernes.",
     "Su expediente se encuentra en fase de análisis. Le rogamos disculpe las molestias ocasionadas y agradecemos su paciencia."),
    ("No me llega la tarjeta nueva y la vieja ha caducado.",
     "Siento la espera. Pido hoy un duplicado con envío urgente a tu domicilio y mientras tanto te activo la tarjeta virtual en la app. La física llega en 48 horas.",
     "La emisión de tarjetas está sujeta a los plazos del proveedor logístico. Puede consultar el estado en el apartado correspondiente de la aplicación."),
    ("Me han metido comisión de mantenimiento y tengo nómina domiciliada.",
     "Si tienes la nómina domiciliada, esa comisión no toca. La anulo y te devuelvo los 60 euros en la cuenta en 48 horas.",
     "Las comisiones se aplican automáticamente según las condiciones contractuales suscritas. Revise su contrato para más detalle."),
    ("El cajero se ha tragado mi tarjeta.",
     "Qué faena. Doy de baja esa tarjeta para que nadie la use y te emito una nueva hoy. La recibes en 48 horas y puedes pagar con el móvil mientras llega.",
     "Le comunicamos que la retención de tarjetas en cajeros automáticos responde a motivos de seguridad. Deberá personarse en su oficina."),
    ("Quiero saber cuánto me financiáis para un piso de 240.000 euros.",
     "Te lo miro. Con vivienda habitual financiamos hasta el 80 %, serían 192.000 euros, y la cuota no puede pasar del 35 % de tu nómina. Te mando el cálculo exacto mañana.",
     "La concesión de financiación hipotecaria queda sujeta a análisis de riesgo y a la política crediticia de la entidad en cada momento."),
    ("Mi test MiFID ha caducado y no puedo contratar.",
     "Es normal, caduca a los 24 meses. Te dejo el test abierto en la app ahora mismo; en cuanto lo rellenes, en 10 minutos puedes contratar.",
     "La normativa MiFID II exige la actualización periódica del perfil de idoneidad del cliente con carácter previo a la contratación."),
    ("Me he quedado en descubierto y me habéis cobrado 30 euros.",
     "Entiendo el disgusto. Es la primera vez que te pasa, así que te devuelvo los 30 euros hoy y te activo un aviso para que no vuelva a ocurrir.",
     "La comisión por reclamación de posición deudora se encuentra recogida en el libro de tarifas y resulta de aplicación general."),
    ("Han intentado entrar en mi banca online desde otro móvil.",
     "Lo tomo en serio. Cierro todas las sesiones abiertas y fuerzo un cambio de clave ahora. Investigación Financiera revisa el intento en menos de 4 horas.",
     "Los accesos no reconocidos pueden deberse a múltiples causas. Le recomendamos modificar sus credenciales periódicamente."),
    ("Quiero cancelar la tarjeta Premium.",
     "Sin problema. La cancelo hoy y te prorrateo la cuota de los meses que no has usado. Verás el abono en tu cuenta en 5 días hábiles.",
     "La baja de productos debe solicitarse mediante el canal habilitado al efecto y surtirá efectos conforme a lo estipulado."),
    ("No consigo descargar el extracto desde la app.",
     "Lo reviso. Es un fallo conocido en la última versión; mientras lo arreglamos te mando el extracto por correo seguro en menos de 2 horas.",
     "Le sugerimos verificar su conexión, actualizar la aplicación y, en su defecto, contactar con soporte técnico."),
    ("Quiero añadir a mi pareja como titular.",
     "Claro. Necesito su DNI y una firma conjunta, que podéis hacer desde la app. En cuanto firméis, queda activo en 24 horas.",
     "La modificación de la titularidad de las cuentas requiere la cumplimentación de la documentación preceptiva en oficina."),
    ("Me han cobrado comisión por sacar dinero en Londres.",
     "Así es: fuera de la zona euro aplicamos un 4,5 %. Te lo explico en el detalle del cargo y, si viajas a menudo, te cambio a una tarjeta sin esa comisión esta semana.",
     "Las operaciones realizadas en divisa distinta del euro conllevan los costes recogidos en el folleto de tarifas publicado."),
    ("Llevo un mes esperando la devolución de un cargo fraudulento.",
     "Un mes es inaceptable y lo siento. Reclamo hoy a Investigación Financiera con prioridad y te confirmo el abono antes del lunes.",
     "Los procesos de verificación de operaciones fraudulentas pueden extenderse en función de la complejidad del caso."),
    ("No entiendo nada del test de idoneidad que me habéis mandado.",
     "Normal, está escrito en jurídico. Son diez preguntas sobre cuánto riesgo aguantas. Te llamo esta tarde y lo hacemos juntos en diez minutos.",
     "El cuestionario de idoneidad responde a exigencias regulatorias y debe ser cumplimentado por el titular de forma personal."),
    ("¿Por qué me habéis bajado el límite de la tarjeta sin avisar?",
     "Tienes razón en quejarte: deberíamos haberte avisado. Ha sido una revisión automática de riesgo. Lo elevo a Riesgos y te doy respuesta en 48 horas.",
     "Las líneas de crédito son objeto de revisión periódica conforme a la política de riesgos vigente en cada momento."),
    ("He perdido el móvil con la app del banco abierta.",
     "Lo primero: cierro ahora todas las sesiones y bloqueo los pagos desde ese dispositivo. Hecho en un minuto. Luego te mando un enlace para reactivar la app en el móvil nuevo.",
     "En caso de extravío de dispositivos se recomienda proceder al cambio de credenciales a la mayor brevedad posible."),
    ("Quiero traspasar un fondo que tengo en otra entidad.",
     "Nos encargamos nosotros del papeleo. Necesito el nombre del fondo y tu último extracto. El traspaso tarda entre 5 y 8 días hábiles y no tributa.",
     "Los traspasos entre instituciones de inversión colectiva se tramitan conforme a los plazos establecidos por la normativa."),
    ("Me cobráis 60 euros al año por tener la cuenta y no lo sabía.",
     "Entiendo el enfado. Si domicilias la nómina o dos recibos, la comisión desaparece. Te lo dejo preparado hoy y te devuelvo el último cobro.",
     "Las condiciones económicas de los productos fueron comunicadas en el momento de la contratación y se encuentran disponibles."),
]


def preferencias(n_test: int = 4, seed: int = 0
                 ) -> tuple[list[dict[str, str]], list[dict[str, str]]]:
    """Genera los pares de preferencia para el cuaderno de RLHF.

    Devuelve dos listas de diccionarios con claves ``prompt``, ``elegida`` y
    ``rechazada``. La respuesta elegida cumple el manual de atención al cliente
    de Banco Iberia (ATC-01); la rechazada es correcta en castellano pero
    impersonal, sin acción concreta y sin plazo, que es justo lo que el manual
    prohíbe.
    """
    rng = random.Random(seed)
    pares = [{"prompt": p, "elegida": c, "rechazada": r} for p, c, r in _PREFS]
    rng.shuffle(pares)
    return pares[:-n_test], pares[-n_test:]
