"""Configuración compartida por los cinco cuadernos de la demo.

Un solo sitio donde se decide qué modelo se usa, con qué semilla y en qué
dispositivo. Si cambias de máquina, tocas esto y nada más.

    from comun.config import MODELO_CHARLA, MODELO_PEQUE, DEVICE, fijar_semilla
"""

from __future__ import annotations

import os
import platform
import random
import sys
import time
from contextlib import contextmanager

os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "3")
# Sin permisos de administrador, Windows no crea enlaces simbólicos y la caché
# de modelos avisa de ello en cada descarga. Funciona igual, copiando.
if sys.platform.startswith("win"):
    os.environ.setdefault("HF_HUB_DISABLE_SYMLINKS_WARNING", "1")

import numpy as np
import torch

# --------------------------------------------------------------------------
# Modelos. Todos de pesos abiertos y descargables sin pedir permiso a nadie.
# --------------------------------------------------------------------------

# El que conversa: 1.540 millones de parámetros, habla español decente y trae
# chat template con soporte de herramientas. Apache 2.0. Lo usamos en RAG (01)
# y MCP (02), donde solo hacemos inferencia.
MODELO_CHARLA = "Qwen/Qwen2.5-1.5B-Instruct"

# El que entrenamos: 135 millones de parámetros. Cabe entero en RAM y una
# época tarda minutos, no horas. Apache 2.0. Lo usamos en SFT (03), LoRA (04)
# y RLHF (05).
MODELO_PEQUE = "HuggingFaceTB/SmolLM2-135M-Instruct"

# El que convierte texto en vectores, para RAG (01). MIT, 384 dimensiones.
# Los modelos e5 exigen prefijos: "query: " en la pregunta y "passage: " en
# los documentos. Olvidarlos cuesta varios puntos de recuperación.
MODELO_EMBED = "intfloat/multilingual-e5-small"

# El encoder con el que lo comparamos en el cuaderno 01. Apache 2.0.
MODELO_EMBED_ALT = "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2"

def _elegir_dispositivo() -> str:
    """CUDA si la hay, CPU si no. Apple Silicon se avisa pero no se usa.

    En un Mac con chip M, PyTorch ofrece `mps`. Funciona para generar texto,
    pero no todas las operaciones de entrenamiento están implementadas y los
    cuadernos 03, 04 y 05 entrenan. Como los tiempos de esta demo ya son de
    minutos en CPU, el valor seguro es CPU, que es además lo único probado.
    Quien quiera probar su GPU integrada: DEMO_DEVICE=mps antes de arrancar
    Jupyter.
    """
    forzado = os.environ.get("DEMO_DEVICE", "").strip().lower()
    if forzado:
        return forzado
    if torch.cuda.is_available():
        return "cuda"
    return "cpu"


def hay_mps() -> bool:
    """¿Es un Mac con Apple Silicon y PyTorch ve la GPU integrada?"""
    backend = getattr(torch.backends, "mps", None)
    return bool(backend is not None and backend.is_available())


DEVICE = _elegir_dispositivo()

# En CPU, float32 sobre un modelo de 1,5 B ocupa 6 GB y se pelea con el resto
# del portátil. bfloat16 lo deja en 3 GB y, medido en esta máquina, va diez
# veces más rápido justo por eso. En GPU float16 es lo habitual.
DTYPE_CHARLA = torch.bfloat16 if DEVICE == "cpu" else torch.float16

# El modelo que se entrena va en float32: los gradientes de bfloat16 en CPU
# dan problemas de precisión y 135 M en float32 son solo 540 MB.
DTYPE_ENTRENO = torch.float32

SEED = 0

# En CPU, PyTorch por defecto se queda corto de hilos dentro de Jupyter.
if DEVICE == "cpu":
    torch.set_num_threads(max(1, (os.cpu_count() or 4) // 2))


def fijar_semilla(seed: int = SEED) -> None:
    """Fija las tres fuentes de aleatoriedad que usamos. Sin esto no hay demo
    reproducible: cada ejecución daría números distintos y el alumno no sabría
    si lo que ve es el efecto del método o el del ruido."""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def mil(n: float) -> str:
    """1234567 -> '1.234.567'. Separador de miles a la española."""
    return f"{int(n):,}".replace(",", ".")


def tam_mb(modelo: torch.nn.Module) -> float:
    """Megabytes que ocupan los pesos de un modelo en el precisión actual."""
    return sum(p.numel() * p.element_size() for p in modelo.parameters()) / 1024**2


@contextmanager
def cronometro(etiqueta: str):
    """with cronometro('generar'): ...  -> imprime cuánto tardó el bloque."""
    t0 = time.perf_counter()
    yield
    print(f"[{etiqueta}] {time.perf_counter() - t0:.1f} s")


def resumen_entorno() -> None:
    print(f"Sistema        : {platform.system()} {platform.release()} "
          f"({platform.machine()})")
    print(f"Python         : {platform.python_version()}")
    print(f"PyTorch        : {torch.__version__}")
    print(f"Dispositivo    : {DEVICE}")
    if DEVICE == "cuda":
        libre, total = torch.cuda.mem_get_info()
        print(f"GPU            : {torch.cuda.get_device_name(0)}")
        print(f"VRAM libre     : {libre / 1024**3:.1f} / {total / 1024**3:.1f} GB")
    else:
        print(f"Hilos de CPU   : {torch.get_num_threads()}")
        if os.environ.get("DEMO_DEVICE"):
            print("Dispositivo fijado a mano con DEMO_DEVICE.")
        elif hay_mps():
            print("Mac con Apple Silicon: la demo va en CPU a propósito, que es "
                  "lo probado. Con DEMO_DEVICE=mps usarías la GPU integrada.")
        else:
            print("Sin GPU: todo funciona igual, solo que más despacio.")
    print(f"Semilla        : {SEED}")
