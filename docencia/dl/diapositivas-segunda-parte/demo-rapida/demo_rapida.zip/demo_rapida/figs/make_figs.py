#!/usr/bin/env python3
"""Genera todas las figuras de los cuadernos de demo_rapida.

    python3 figs/make_figs.py

Paleta y helpers vienen de common/figlib.py, que es la misma biblioteca con la
que están hechos los slides del curso. Las figuras salen en PNG a 150 ppp
porque su destino es un cuaderno de Jupyter, no un PDF de LaTeX.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

os.environ["MPLBACKEND"] = "Agg"  # antes de tocar matplotlib: esto no abre ventanas

AQUI = Path(__file__).resolve().parent
sys.path.insert(0, str(AQUI.parent.parent / "common"))

import matplotlib as mpl
import numpy as np
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch

import figlib as F
import matplotlib.pyplot as plt

mpl.rcParams.update({"figure.dpi": 150, "savefig.dpi": 150})

INK, GOLD, DEEP, PALE, MUTE, RULE = (
    F.C_INK, F.C_GOLD, F.C_GOLD_DEEP, F.C_GOLD_PALE, F.C_MUTE, F.C_RULE)


# --------------------------------------------------------------------------
# Helpers de dibujo
# --------------------------------------------------------------------------

def lienzo(w: float = 11.0, h: float = 6.2, titulo: str | None = None):
    """Eje limpio en coordenadas 0..100 x 0..100, sin marco."""
    fig, ax = plt.subplots(figsize=(w, h))
    ax.set_xlim(0, 100)
    ax.set_ylim(0, 100)
    ax.axis("off")
    if titulo:
        ax.text(50, 97, titulo, ha="center", va="top", fontsize=14.5,
                fontweight="bold", color=INK)
        ax.plot([18, 82], [92.5, 92.5], color=GOLD, lw=1.1)
    return fig, ax


def caja(ax, x, y, w, h, titulo, cuerpo="", color=INK, relleno="white",
         ts=10.5, bs=8.8, lw=1.1):
    """Caja redondeada con título en negrita y cuerpo opcional debajo."""
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.6,rounding_size=1.6",
                                facecolor=relleno, edgecolor=color, lw=lw, zorder=2))
    if cuerpo:
        ax.text(x + w / 2, y + h * 0.70, titulo, ha="center", va="center",
                fontsize=ts, fontweight="bold", color=color, zorder=3)
        ax.text(x + w / 2, y + h * 0.30, cuerpo, ha="center", va="center",
                fontsize=bs, color=INK, zorder=3, linespacing=1.45)
    else:
        ax.text(x + w / 2, y + h / 2, titulo, ha="center", va="center",
                fontsize=ts, fontweight="bold", color=color, zorder=3)


def flecha(ax, p0, p1, color=GOLD, lw=1.6, estilo="-|>", rad=0.0, texto=None,
           ts=8.5, dy=2.0):
    ax.add_patch(FancyArrowPatch(p0, p1, arrowstyle=estilo, mutation_scale=14,
                                 color=color, lw=lw, zorder=4,
                                 connectionstyle=f"arc3,rad={rad}"))
    if texto:
        ax.text((p0[0] + p1[0]) / 2, (p0[1] + p1[1]) / 2 + dy, texto,
                ha="center", va="bottom", fontsize=ts, color=color, zorder=5)


# ==========================================================================
# 00 — El mapa de las cinco técnicas
# ==========================================================================

def fig_mapa() -> None:
    fig, ax = lienzo(12.0, 6.8, "Las cinco técnicas, ordenadas por lo que tocan")

    ax.set_xlim(-2, 102)

    tarjetas = [
        (0.5, "RAG", "le das los documentos\nbuenos en el prompt", GOLD),
        (20.5, "MCP", "le das herramientas\nque ejecutan cosas", GOLD),
        (40.5, "SFT", "mueves todos los pesos\ncon ejemplos resueltos", DEEP),
        (60.5, "LoRA", "mueves un 0,5 % de\nlos pesos, mismo efecto", DEEP),
        (80.5, "RLHF", "mueves los pesos hacia\nlo que la gente prefiere", INK),
    ]
    y, w = 30, 19
    for i, (x, nom, desc, col) in enumerate(tarjetas):
        ax.add_patch(FancyBboxPatch((x, y), w, 46,
                                    boxstyle="round,pad=0.5,rounding_size=2",
                                    facecolor=PALE if col is GOLD else "white",
                                    edgecolor=col, lw=1.4, zorder=2))
        cx = x + w / 2
        ax.text(cx, y + 39, f"{i + 1}", ha="center", fontsize=9, color=MUTE)
        ax.text(cx, y + 31, nom, ha="center", fontsize=16, fontweight="bold", color=col)
        ax.plot([cx - 5, cx + 5], [y + 27, y + 27], color=RULE, lw=1.0)
        ax.text(cx, y + 17, desc, ha="center", va="center", fontsize=8.8,
                color=INK, linespacing=1.5)
        ax.text(cx, y + 6, "conocimiento" if i < 2 else "comportamiento",
                ha="center", fontsize=8.2, color=MUTE, style="italic")
        ax.add_patch(FancyArrowPatch((cx, y - 1), (cx, 21.5), arrowstyle="-",
                                     color=RULE, lw=0.9, linestyle=(0, (2, 2))))

    ax.plot([0, 99.5], [20, 20], color=INK, lw=1.0)
    ax.text(50, 24.5, "¿hay que reentrenar el modelo?", ha="center", fontsize=10,
            color=MUTE, style="italic", zorder=6,
            bbox=dict(boxstyle="square,pad=0.3", fc="white", ec="none"))
    for x in (40, 80):
        ax.plot([x, x], [18.5, 21.5], color=INK, lw=1.0)
    for x, etq in [(20, "no, solo cambias\nlo que le metes"),
                   (60, "sí, pero poco"),
                   (90, "sí, y además con\njuicio humano")]:
        ax.text(x, 14, etq, ha="center", va="center", fontsize=8.8, color=MUTE,
                linespacing=1.5)

    ax.text(50, 5, "Regla práctica: si el problema es que el modelo no SABE algo, empieza por RAG o MCP.\n"
                   "Si el problema es que no HACE lo que quieres, necesitas SFT, LoRA o RLHF.",
            ha="center", va="center", fontsize=9.4, color=INK, linespacing=1.7)
    F.save(fig, AQUI / "00_mapa.png")


def fig_quien_usa_que() -> None:
    fig, ax = lienzo(11.5, 6.2, "Quién pone esto en producción, y para qué")
    filas = [
        (68, ["santander", "bbva", "caixabank"],
         "RAG sobre normativa interna y contratos",
         "el asesor pregunta en lenguaje natural y recibe la cláusula con su cita"),
        (46, ["anthropic", "openai", "microsoft"],
         "MCP como estándar de conexión a herramientas",
         "un mismo servidor sirve a Claude, a un IDE y a un agente propio"),
        (24, ["inditex", "telefonica", "iberdrola"],
         "SFT y LoRA sobre modelos abiertos",
         "un modelo ajustado al dominio sale más barato que llamar a una API"),
        (2, ["meta", "mistral", "huggingface"],
         "RLHF antes de publicar los pesos",
         "separa un modelo base de uno que puedes poner delante de un cliente"),
    ]
    for y, logos, titulo, pie in filas:
        ax.add_patch(FancyBboxPatch((3, y), 94, 17,
                                    boxstyle="round,pad=0.5,rounding_size=1.5",
                                    facecolor="white", edgecolor=RULE, lw=1.0, zorder=1))
        for i, nom in enumerate(logos):
            F.place_logo(ax, nom, (12 + i * 11, y + 8.5), target_max=44)
        ax.text(46, y + 11, titulo, ha="left", va="center", fontsize=10.5,
                fontweight="bold", color=INK)
        ax.text(46, y + 5, pie, ha="left", va="center", fontsize=8.5, color=MUTE)
    F.save(fig, AQUI / "00_quien_usa_que.png")


# ==========================================================================
# 01 — RAG
# ==========================================================================

def fig_rag_flujo() -> None:
    fig, ax = lienzo(12.0, 6.4, "RAG: cinco pasos, y solo el último es el modelo")

    pasos = [
        (2.0, "1. Trocear", "los documentos se parten\nen fragmentos de unas\npocas frases"),
        (21.5, "2. Vectorizar", "cada fragmento pasa\na ser un vector de\n384 números"),
        (41.0, "3. Indexar", "los vectores van a una\nbase vectorial: FAISS,\npgvector, Qdrant"),
        (60.5, "4. Recuperar", "la pregunta se vectoriza\ny se traen los k\nvecinos más próximos"),
        (80.0, "5. Generar", "los k fragmentos entran\nen el prompt y el modelo\nredacta con ellos"),
    ]
    for i, (x, tit, desc) in enumerate(pasos):
        col = GOLD if i == 4 else INK
        ax.add_patch(FancyBboxPatch((x, 40), 16, 36,
                                    boxstyle="round,pad=0.5,rounding_size=2",
                                    facecolor=PALE if i == 4 else "white",
                                    edgecolor=col, lw=1.3, zorder=2))
        ax.text(x + 8, 70, tit, ha="center", fontsize=11, fontweight="bold", color=col)
        ax.plot([x + 2.5, x + 13.5], [66.5, 66.5], color=RULE, lw=0.9)
        ax.text(x + 8, 54, desc, ha="center", va="center", fontsize=8.3,
                color=INK, linespacing=1.5)
        if i < 4:
            ax.add_patch(FancyArrowPatch((x + 17.0, 58), (x + 18.9, 58),
                                         arrowstyle="-|>", mutation_scale=13,
                                         color=GOLD, lw=1.7, zorder=4))

    ax.text(4, 32, "Offline: se hace una vez y se guarda",
            fontsize=9.5, color=MUTE, style="italic")
    ax.plot([2, 57.5], [29, 29], color=MUTE, lw=0.8, linestyle=(0, (3, 3)))
    ax.text(62, 32, "Online: ocurre en cada pregunta del usuario",
            fontsize=9.5, color=GOLD, style="italic")
    ax.plot([60, 96.5], [29, 29], color=GOLD, lw=0.8, linestyle=(0, (3, 3)))

    ax.text(50, 19, "Lo que cambia respecto a preguntar a pelo: el modelo deja de responder de memoria\n"
                    "y pasa a responder leyendo. Por eso puede citar la fuente, y por eso actualizar el\n"
                    "conocimiento cuesta reindexar un documento en vez de reentrenar mil millones de pesos.",
            ha="center", va="top", fontsize=9.4, color=INK, linespacing=1.6)
    F.save(fig, AQUI / "01_rag_flujo.png")


def fig_ventana() -> None:
    fig, axes = plt.subplots(1, 2, figsize=(11.5, 5.0))

    ax = axes[0]
    etq = ["La normativa\ninterna completa", "Lo que cabe en\nla ventana (32k)", "Lo que recupera\nel RAG (k=3)"]
    val = [4_200_000, 32_000, 420]
    col = [MUTE, INK, GOLD]
    b = ax.bar(etq, val, color=col, width=0.58)
    ax.set_yscale("log")
    ax.set_ylabel("tokens (escala logarítmica)")
    ax.set_title("El corpus nunca cabe en la ventana", fontsize=12, fontweight="bold", pad=12)
    for r, v in zip(b, val):
        ax.text(r.get_x() + r.get_width() / 2, v * 1.35, f"{v:,}".replace(",", "."),
                ha="center", fontsize=9.5, color=INK, fontweight="bold")
    ax.set_ylim(100, 2e7)
    ax.tick_params(labelsize=9)

    ax = axes[1]
    k = np.arange(1, 13)
    cobertura = 1 - np.exp(-0.45 * k)
    coste = 0.6 + 0.42 * k
    ax.plot(k, cobertura * 100, "o-", color=GOLD, lw=2.2, ms=6,
            label="% de preguntas con la respuesta dentro")
    ax.plot(k, coste / coste[-1] * 100, "s--", color=MUTE, lw=1.8, ms=5,
            label="coste y latencia del prompt (normalizado)")
    ax.axvline(3, color=DEEP, lw=1.2, linestyle=":")
    ax.text(3.2, 20, "k = 3\nel punto donde deja\nde compensar subir",
            fontsize=8.8, color=DEEP, linespacing=1.4)
    ax.set_xlabel("k: cuántos fragmentos metes en el prompt")
    ax.set_ylabel("porcentaje")
    ax.set_title("Más contexto cuesta dinero y latencia", fontsize=12, fontweight="bold", pad=12)
    ax.legend(fontsize=8.4, loc="center right", frameon=False)
    ax.tick_params(labelsize=9)

    fig.tight_layout()
    F.save(fig, AQUI / "01_ventana.png")


# ==========================================================================
# 02 — MCP
# ==========================================================================

def fig_mcp_arquitectura() -> None:
    fig, ax = lienzo(11.8, 6.4, "MCP: un enchufe estándar entre el modelo y el mundo")

    caja(ax, 4, 52, 26, 28, "HOST", "la aplicación que ve el usuario\nClaude Desktop, un IDE,\ntu cuaderno de Jupyter",
         color=INK, relleno="white", ts=12)
    caja(ax, 4, 20, 26, 24, "MODELO", "Qwen, Claude, Llama...\ndecide QUÉ herramienta\nusar, no la ejecuta",
         color=GOLD, relleno=PALE, ts=12)
    flecha(ax, (17, 52), (17, 44.5), color=RULE, estilo="<|-|>")

    caja(ax, 36, 44, 17, 22, "CLIENTE\nMCP", "una sesión\npor servidor", color=DEEP, relleno="white", ts=10)

    servidores = [(62, 68, "Servidor\nbanco-iberia", "saldo, cuota,\nnormativa"),
                  (62, 40, "Servidor\nfilesystem", "leer y escribir\nficheros"),
                  (62, 12, "Servidor\nGitHub", "issues, PRs,\ncommits")]
    for x, y, tit, desc in servidores:
        caja(ax, x, y, 22, 20, tit, desc, color=INK, relleno="white", ts=10, bs=8.4)
        flecha(ax, (53.5, 55), (x - 0.6, y + 10), color=GOLD, rad=0.12,
               texto=None)

    caja(ax, 89, 68, 9, 20, "API", "", color=MUTE, relleno="white", ts=9)
    caja(ax, 89, 40, 9, 20, "disco", "", color=MUTE, relleno="white", ts=9)
    caja(ax, 89, 12, 9, 20, "web", "", color=MUTE, relleno="white", ts=9)
    for y in (78, 50, 22):
        flecha(ax, (84.4, y), (88.6, y), color=MUTE, lw=1.2)

    ax.text(40, 28, "JSON-RPC 2.0\npor stdio o HTTP", ha="center", fontsize=8.8,
            color=GOLD, style="italic", linespacing=1.5)

    ax.text(50, 5.5, "Antes de MCP, cada aplicación escribía su propio pegamento para cada herramienta: N aplicaciones × M herramientas.\n"
                     "Con MCP se escribe el servidor una vez y lo consume cualquier host que hable el protocolo: N + M.",
            ha="center", va="center", fontsize=9.2, color=INK, linespacing=1.6)
    F.save(fig, AQUI / "02_mcp_arquitectura.png")


def fig_mcp_secuencia() -> None:
    fig, ax = lienzo(11.5, 6.6, "Un turno completo: de la pregunta a la respuesta con datos reales")

    carriles = [(13, "USUARIO", MUTE), (35, "HOST + MODELO", GOLD),
                (60, "CLIENTE MCP", DEEP), (84, "SERVIDOR", INK)]
    for x, nom, col in carriles:
        ax.add_patch(FancyBboxPatch((x - 10, 80), 20, 8,
                                    boxstyle="round,pad=0.4,rounding_size=1.2",
                                    facecolor="white", edgecolor=col, lw=1.2, zorder=3))
        ax.text(x, 84, nom, ha="center", va="center", fontsize=9.5,
                fontweight="bold", color=col, zorder=4)
        ax.plot([x, x], [10, 80], color=RULE, lw=0.9, linestyle=(0, (2, 3)), zorder=1)

    pasos = [
        (74, 13, 35, "\"¿qué cuota me quedaría?\"", GOLD),
        (66, 35, 60, "el modelo emite una llamada:\ncalcular_cuota_hipoteca(...)", GOLD),
        (56, 60, 84, "tools/call\n{\"name\": ..., \"arguments\": {...}}", DEEP),
        (46, 84, 84, "el servidor ejecuta\nPython de verdad", INK),
        (36, 84, 60, "result\n{\"content\": [{\"text\": \"Cuota mensual: 819,87 €\"}]}", DEEP),
        (26, 60, 35, "el resultado entra en el prompt\ncomo mensaje de rol 'tool'", GOLD),
        (18, 35, 35, "segunda pasada del modelo,\nahora con el dato delante", GOLD),
        (12, 35, 13, "\"Serían 819,87 € al mes durante 30 años.\"", GOLD),
    ]
    for y, x0, x1, texto, col in pasos:
        if x0 == x1:
            izq = x0 > 70
            d = -7 if izq else 7
            ax.add_patch(FancyArrowPatch((x0, y + 3), (x0 + d, y + 3), arrowstyle="-",
                                         color=col, lw=1.4))
            ax.add_patch(FancyArrowPatch((x0 + d, y + 3), (x0 + d, y), arrowstyle="-",
                                         color=col, lw=1.4))
            ax.add_patch(FancyArrowPatch((x0 + d, y), (x0 - 0.4 * d / 7, y),
                                         arrowstyle="-|>", mutation_scale=12,
                                         color=col, lw=1.4))
            ax.text(x0 + d - 2.5 * (1 if izq else -1), y + 1.5, texto,
                    ha="right" if izq else "left", va="center", fontsize=8.4,
                    color=col, linespacing=1.5)
        else:
            flecha(ax, (x0, y), (x1, y), color=col, lw=1.5)
            ax.text((x0 + x1) / 2, y + 1.6, texto, ha="center", va="bottom",
                    fontsize=8.4, color=col, linespacing=1.5)

    ax.text(50, 4, "El modelo nunca ejecuta nada. Escribe texto que dice qué quiere ejecutar; el host lo intercepta,\n"
                   "lo valida y decide si lo ejecuta. Toda la seguridad de un agente vive en ese punto.",
            ha="center", va="center", fontsize=9.2, color=INK, linespacing=1.6)
    F.save(fig, AQUI / "02_mcp_secuencia.png")


# ==========================================================================
# 03 — SFT
# ==========================================================================

def fig_sft_mascara() -> None:
    fig, ax = lienzo(12.0, 5.8, "SFT: la pérdida solo se cobra sobre la respuesta")

    tokens_p = ["<|im_start|>", "user", "Me", "han", "cobrado", "240", "€", "<|im_end|>",
                "<|im_start|>", "assistant"]
    tokens_r = ["CATEGORIA", ":", "fraude", "URGENCIA", ":", "alta", "<|im_end|>"]

    x = 3.0
    anchos_p = [max(6.0, len(t) * 0.62) for t in tokens_p]
    anchos_r = [max(6.0, len(t) * 0.62) for t in tokens_r]
    total = sum(anchos_p) + sum(anchos_r)
    esc = 94.0 / total
    anchos_p = [a * esc for a in anchos_p]
    anchos_r = [a * esc for a in anchos_r]

    for t, w in zip(tokens_p, anchos_p):
        ax.add_patch(FancyBboxPatch((x, 58), w - 0.6, 11,
                                    boxstyle="round,pad=0.2,rounding_size=1",
                                    facecolor="#EFEFEF", edgecolor=MUTE, lw=0.9))
        ax.text(x + (w - 0.6) / 2, 66, t, ha="center", va="center", fontsize=6.6, color=MUTE)
        ax.text(x + (w - 0.6) / 2, 61.5, "-100", ha="center", va="center",
                fontsize=7.2, color=MUTE, fontweight="bold")
        x += w
    x_corte = x
    for t, w in zip(tokens_r, anchos_r):
        ax.add_patch(FancyBboxPatch((x, 58), w - 0.6, 11,
                                    boxstyle="round,pad=0.2,rounding_size=1",
                                    facecolor=PALE, edgecolor=GOLD, lw=1.1))
        ax.text(x + (w - 0.6) / 2, 66, t, ha="center", va="center", fontsize=6.6, color=INK)
        ax.text(x + (w - 0.6) / 2, 61.5, "id", ha="center", va="center",
                fontsize=7.2, color=DEEP, fontweight="bold")
        x += w

    ax.plot([x_corte - 0.3, x_corte - 0.3], [52, 76], color=INK, lw=1.3, linestyle=(0, (4, 2)))
    ax.text(3, 75, "PROMPT  ·  etiqueta = -100  ·  PyTorch lo ignora en la cross-entropy",
            fontsize=9.4, color=MUTE)
    ax.text(x_corte + 1, 75, "RESPUESTA  ·  aquí sí se calcula la pérdida",
            fontsize=9.4, color=DEEP, fontweight="bold")

    ax.text(50, 46, r"$\mathcal{L} = -\dfrac{1}{|R|}\sum_{t \in R} \log p_\theta(y_t \mid y_{<t})$",
            ha="center", fontsize=17, color=INK)
    ax.text(50, 37, "R es el conjunto de posiciones de la respuesta. Es la MISMA pérdida del preentrenamiento,\n"
                    "token siguiente dado el anterior. Lo único que cambia es sobre qué datos y en qué posiciones.",
            ha="center", va="top", fontsize=9.4, color=INK, linespacing=1.6)

    ax.text(50, 24, "Por qué enmascarar el prompt", ha="center", fontsize=10.5,
            fontweight="bold", color=INK)
    ax.text(50, 19, "Si no lo haces, el modelo gasta capacidad aprendiendo a generar quejas de clientes,\n"
                    "que es justo lo que no le pides. Queremos p(ficha | queja), no p(queja).\n"
                    "El bug es silencioso: entrena sin fallar y sale peor.",
            ha="center", va="top", fontsize=9.2, color=MUTE, linespacing=1.6)
    F.save(fig, AQUI / "03_sft_mascara.png")


def fig_sft_fases() -> None:
    fig, ax = lienzo(11.8, 5.2, "Dónde encaja el SFT en la vida de un modelo")
    fases = [
        (3, "Preentrenamiento", "billones de tokens\nde internet", "meses · miles de GPU\n~10 M €", MUTE),
        (28, "SFT", "miles de pares\ninstrucción → respuesta", "horas · 1 GPU\n~20 €", GOLD),
        (53, "RLHF", "decenas de miles de\ncomparaciones humanas", "días · varias GPU\n~1000 €", DEEP),
        (78, "Tu ajuste", "160 ejemplos\nde tu empresa", "minutos · tu portátil\n0 €", INK),
    ]
    for x, tit, datos, coste, col in fases:
        ax.add_patch(FancyBboxPatch((x, 30), 19, 46,
                                    boxstyle="round,pad=0.7,rounding_size=2",
                                    facecolor=PALE if col in (GOLD, INK) else "white",
                                    edgecolor=col, lw=1.3, zorder=2))
        ax.text(x + 9.5, 69, tit, ha="center", fontsize=12, fontweight="bold", color=col)
        ax.plot([x + 3, x + 16], [65, 65], color=RULE, lw=0.9)
        ax.text(x + 9.5, 55, datos, ha="center", va="center", fontsize=8.8,
                color=INK, linespacing=1.5)
        ax.text(x + 9.5, 39, coste, ha="center", va="center", fontsize=8.6,
                color=MUTE, linespacing=1.5, style="italic")
        if x < 78:
            ax.add_patch(FancyArrowPatch((x + 19.3, 53), (x + 24.7, 53),
                                         arrowstyle="-|>", mutation_scale=14,
                                         color=GOLD, lw=1.8))
    ax.text(50, 20, "Las tres primeras ya están hechas cuando te descargas los pesos. Tú entras en la cuarta.\n"
                    "Partir del modelo instruido y no del base es lo que convierte semanas de cómputo en minutos.",
            ha="center", va="top", fontsize=9.4, color=INK, linespacing=1.6)
    F.save(fig, AQUI / "03_sft_fases.png")


# ==========================================================================
# 04 — LoRA
# ==========================================================================

def fig_lora_descomposicion() -> None:
    fig, ax = lienzo(11.8, 6.2, "LoRA: la actualización de pesos cabe en dos matrices flacas")

    ax.text(50, 85, r"$h = W_0\,x + \frac{\alpha}{r} B A\, x$", ha="center",
            fontsize=18, color=INK)
    ax.text(50, 78, "r = 8 frente a 1.536: la actualización se obliga a vivir en un subespacio de rango 8",
            ha="center", fontsize=9.2, color=MUTE, style="italic")

    ax.add_patch(FancyBboxPatch((5, 26), 26, 42, boxstyle="round,pad=0.4,rounding_size=1",
                                facecolor="#EFEFEF", edgecolor=MUTE, lw=1.4))
    ax.text(18, 50, r"$W_0$", ha="center", fontsize=20, color=MUTE)
    ax.text(18, 40, "congelada\nd × k", ha="center", fontsize=9.5, color=MUTE, linespacing=1.5)
    ax.text(18, 71, "pesos originales", ha="center", fontsize=9.5, color=MUTE)
    ax.text(18, 21, "1.536 × 1.536 = 2.359.296", ha="center", fontsize=8.6, color=MUTE)

    ax.text(35, 46, "+", ha="center", va="center", fontsize=24, color=INK)

    ax.text(57, 71, "lo único que se entrena", ha="center", fontsize=10.5,
            fontweight="bold", color=DEEP)

    ax.add_patch(FancyBboxPatch((39, 26), 5.5, 42, boxstyle="round,pad=0.4,rounding_size=1",
                                facecolor=PALE, edgecolor=GOLD, lw=1.6))
    ax.text(41.7, 46, r"$B$", ha="center", va="center", fontsize=18, color=DEEP)
    ax.text(41.7, 64, "d × r", ha="center", fontsize=9, color=DEEP)
    ax.text(41.7, 21, "1.536 × 8", ha="center", fontsize=8.6, color=DEEP)

    ax.add_patch(FancyBboxPatch((48, 43.5), 24, 5.5, boxstyle="round,pad=0.4,rounding_size=1",
                                facecolor=PALE, edgecolor=GOLD, lw=1.6))
    ax.text(60, 46.2, r"$A$", ha="center", va="center", fontsize=18, color=DEEP)
    ax.text(60, 54, "r × k", ha="center", fontsize=9, color=DEEP)
    ax.text(60, 37, "8 × 1.536", ha="center", fontsize=8.6, color=DEEP)

    ax.text(78, 46, "=", ha="center", va="center", fontsize=24, color=INK)

    ax.add_patch(FancyBboxPatch((83, 26), 12, 42, boxstyle="round,pad=0.4,rounding_size=1",
                                facecolor="white", edgecolor=INK, lw=1.4))
    ax.text(89, 50, r"$W$", ha="center", fontsize=20, color=INK)
    ax.text(89, 40, "en inferencia\nse fusiona", ha="center", fontsize=8.6,
            color=INK, linespacing=1.5)

    ax.text(50, 14, "24.576 parámetros entrenables en lugar de 2.359.296 por capa: un 1,04 %.\n"
                    "B arranca en cero, así que al empezar el entrenamiento el modelo es byte a byte el original.\n"
                    "Al terminar, W₀ + BA se puede fusionar y servir sin coste adicional de latencia.",
            ha="center", va="top", fontsize=9.4, color=INK, linespacing=1.7)
    F.save(fig, AQUI / "04_lora_descomposicion.png")


def fig_lora_coste() -> None:
    fig, axes = plt.subplots(1, 2, figsize=(11.5, 5.0))

    modelos = ["SmolLM2\n135M", "Qwen2.5\n1.5B", "Llama 3\n8B", "Llama 3\n70B"]
    totales = np.array([135e6, 1.54e9, 8.03e9, 70.6e9])
    lora = totales * 0.0042  # r=8 sobre las proyecciones de atención, orden de magnitud típico

    ax = axes[0]
    x = np.arange(len(modelos))
    ax.bar(x - 0.2, totales, 0.38, color=MUTE, label="SFT completo: todos los pesos")
    ax.bar(x + 0.2, lora, 0.38, color=GOLD, label="LoRA r=8: solo A y B")
    ax.set_yscale("log")
    ax.set_xticks(x, modelos, fontsize=8.6)
    ax.set_ylabel("parámetros entrenables (log)")
    ax.set_title("Lo que el optimizador tiene que mover", fontsize=12, fontweight="bold", pad=12)
    ax.legend(fontsize=8.4, frameon=False, loc="upper left")
    for xi, t, l in zip(x, totales, lora):
        ax.text(xi + 0.2, l * 1.5, f"{l/1e6:.1f}M", ha="center", fontsize=8, color=DEEP)
    ax.set_ylim(1e5, 1e12)

    ax = axes[1]
    # Memoria de entrenamiento con Adam en fp16/fp32 mixto: pesos + grad + 2 momentos.
    mem_full = totales * (2 + 2 + 4 + 4 + 4) / 1024**3
    mem_lora = (totales * 2 + lora * (2 + 4 + 4 + 4)) / 1024**3
    ax.bar(x - 0.2, mem_full, 0.38, color=MUTE, label="SFT completo")
    ax.bar(x + 0.2, mem_lora, 0.38, color=GOLD, label="LoRA r=8")
    ax.axhline(24, color=DEEP, lw=1.3, linestyle="--")
    ax.text(-0.45, 30, "24 GB (una RTX 4090)", fontsize=8.2, color=DEEP, ha="left")
    ax.text(-0.45, 0.075, "LoRA sobre 70B sigue sin caber en una 4090: para eso está QLoRA,\n"
                          "que además cuantiza W₀ a 4 bits.",
            fontsize=7.8, color=MUTE, ha="left", linespacing=1.4)
    ax.set_yscale("log")
    ax.set_xticks(x, modelos, fontsize=8.6)
    ax.set_ylabel("memoria de entrenamiento, GB (log)")
    ax.set_title("Dónde está el ahorro de verdad: el estado de Adam",
                 fontsize=12, fontweight="bold", pad=12)
    ax.legend(fontsize=8.4, frameon=False, loc="upper left")
    ax.set_ylim(0.05, 3000)

    fig.tight_layout()
    F.save(fig, AQUI / "04_lora_coste.png")


# ==========================================================================
# 05 — RLHF
# ==========================================================================

def fig_rlhf_etapas() -> None:
    fig, ax = lienzo(12.0, 6.2, "RLHF: tres etapas, y la humana está en la de en medio")

    etapas = [
        (3, 21, "1. SFT", "El modelo base aprende\nel formato de una conversación\na partir de ejemplos\nescritos por humanos.",
         "pérdida: cross-entropy", GOLD),
        (27.5, 21, "2. Modelo de\nrecompensa", "A humanos se les enseñan\ndos respuestas y eligen cuál\nprefieren. Un modelo aprende\na predecir esa elección.",
         "pérdida: Bradley-Terry", DEEP),
        (52, 22, "3. Optimización\nde política", "El modelo genera, el modelo\nde recompensa puntúa, y la\npolítica se mueve hacia lo\npuntuado alto sin alejarse del SFT.",
         "PPO, GRPO... o DPO", INK),
    ]
    for x, w, tit, desc, pie, col in etapas:
        ax.add_patch(FancyBboxPatch((x, 32), w, 46,
                                    boxstyle="round,pad=0.6,rounding_size=2",
                                    facecolor=PALE if col is not INK else "white",
                                    edgecolor=col, lw=1.4, zorder=2))
        ax.text(x + w / 2, 72, tit, ha="center", va="center", fontsize=11,
                fontweight="bold", color=col, linespacing=1.4)
        ax.plot([x + 3, x + w - 3], [66, 66], color=RULE, lw=0.9)
        ax.text(x + w / 2, 53, desc, ha="center", va="center", fontsize=8.2,
                color=INK, linespacing=1.6)
        ax.text(x + w / 2, 37, pie, ha="center", va="center", fontsize=8.6,
                color=col, style="italic")
        if x < 52:
            ax.add_patch(FancyArrowPatch((x + w + 0.8, 55), (x + w + 2.7, 55),
                                         arrowstyle="-|>", mutation_scale=14,
                                         color=GOLD, lw=1.8))

    ax.add_patch(FancyBboxPatch((77, 32), 20, 46,
                                boxstyle="round,pad=0.6,rounding_size=2",
                                facecolor="white", edgecolor=MUTE, lw=1.2,
                                linestyle=(0, (4, 3)), zorder=2))
    ax.text(87, 72, "DPO", ha="center", va="center", fontsize=11,
            fontweight="bold", color=MUTE)
    ax.plot([80, 94], [66, 66], color=RULE, lw=0.9)
    ax.text(87, 51, "El atajo de 2023: se demuestra\nque la política óptima de la\netapa 3 se puede obtener en\nuna sola pérdida sobre las\npreferencias, sin modelo de\nrecompensa y sin generar nada.",
            ha="center", va="center", fontsize=8.2, color=INK, linespacing=1.6)
    ax.add_patch(FancyArrowPatch((38, 31), (85, 31), arrowstyle="-|>", mutation_scale=14,
                                 color=MUTE, lw=1.4, linestyle=(0, (4, 3)),
                                 connectionstyle="arc3,rad=-0.16"))
    ax.text(61, 18, "DPO se salta las etapas 2 y 3", ha="center", fontsize=9,
            color=MUTE, style="italic")

    ax.text(50, 8, "El dato caro es el de la etapa 2: comparaciones humanas. Llama 2 usó cerca de 1,4 millones.\n"
                   "La etapa 3 es cómputo, y el cómputo se abarata solo.",
            ha="center", va="center", fontsize=9.4, color=INK, linespacing=1.7)
    F.save(fig, AQUI / "05_rlhf_etapas.png")


def fig_bradley_terry() -> None:
    fig, axes = plt.subplots(1, 2, figsize=(11.5, 5.0))

    ax = axes[0]
    m = np.linspace(-6, 6, 400)
    p = 1 / (1 + np.exp(-m))
    ax.plot(m, p, color=GOLD, lw=2.6)
    ax.axhline(0.5, color=MUTE, lw=0.8, linestyle=":")
    ax.axvline(0, color=MUTE, lw=0.8, linestyle=":")
    ax.fill_between(m, 0, p, where=m > 0, color=PALE, alpha=0.8)
    ax.scatter([2.5], [1 / (1 + np.exp(-2.5))], s=70, color=DEEP, zorder=5)
    ax.annotate("el modelo prefiere\nla respuesta buena", (2.5, 0.924), (-5.6, 0.78),
                fontsize=8.6, color=DEEP,
                arrowprops=dict(arrowstyle="-|>", color=DEEP, lw=1.1))
    ax.set_xlabel(r"margen  $r_\phi(x, y_{buena}) - r_\phi(x, y_{mala})$")
    ax.set_ylabel(r"$P(y_{buena} \succ y_{mala})$")
    ax.set_title("Bradley-Terry: de una puntuación a una probabilidad",
                 fontsize=11.5, fontweight="bold", pad=12)
    ax.tick_params(labelsize=9)

    ax = axes[1]
    ax.axis("off")
    ax.text(0.5, 0.95, "La pérdida del modelo de recompensa", ha="center",
            fontsize=11.5, fontweight="bold", color=INK, transform=ax.transAxes)
    ax.text(0.5, 0.80, r"$\mathcal{L}_{RM} = -\log \sigma\left(r_\phi(x,y_b) - r_\phi(x,y_m)\right)$",
            ha="center", fontsize=15, color=INK, transform=ax.transAxes)
    ax.text(0.5, 0.66,
            "No le pedimos al humano que puntúe del 1 al 10.\n"
            "Puntuar es inconsistente entre personas y entre días.\n"
            "Elegir entre dos sí es consistente.",
            ha="center", va="top", fontsize=9.4, color=MUTE,
            transform=ax.transAxes, linespacing=1.7)
    ax.text(0.5, 0.30, r"$\mathcal{L}_{DPO} = -\log \sigma\left(\beta \log \frac{\pi_\theta(y_b|x)}{\pi_{ref}(y_b|x)} - \beta \log \frac{\pi_\theta(y_m|x)}{\pi_{ref}(y_m|x)}\right)$",
            ha="center", fontsize=12.5, color=DEEP, transform=ax.transAxes)
    ax.text(0.5, 0.14,
            "DPO es la misma sigmoide. Lo que cambia es quién hace de r:\n"
            "la propia política, medida como cuánto se ha separado de la de referencia.",
            ha="center", fontsize=9.4, color=DEEP, transform=ax.transAxes, linespacing=1.7)
    ax.plot([0.08, 0.92], [0.43, 0.43], color=RULE, lw=1.0, transform=ax.transAxes)

    fig.tight_layout()
    F.save(fig, AQUI / "05_bradley_terry.png")


def fig_kl() -> None:
    fig, axes = plt.subplots(1, 2, figsize=(11.5, 5.0))

    pasos = np.arange(0, 120)
    ax = axes[0]
    rec_sin = 1.8 * (1 - np.exp(-pasos / 18)) + 0.9 * (1 - np.exp(-pasos / 70))
    rec_con = 1.8 * (1 - np.exp(-pasos / 22))
    ax.plot(pasos, rec_sin, color=MUTE, lw=2.2, label="sin penalización KL")
    ax.plot(pasos, rec_con, color=GOLD, lw=2.4, label="con penalización KL")
    ax.set_xlabel("pasos de optimización")
    ax.set_ylabel("recompensa media según el RM")
    ax.set_title("La recompensa sube en los dos casos", fontsize=11.5,
                 fontweight="bold", pad=12)
    ax.legend(fontsize=8.6, frameon=False, loc="lower right")
    ax.tick_params(labelsize=9)

    ax = axes[1]
    cal_sin = 0.80 * np.exp(-((pasos - 25) / 60) ** 2) + 0.12
    cal_con = 0.80 + 0.12 * (1 - np.exp(-pasos / 30))
    ax.plot(pasos, cal_sin, color=MUTE, lw=2.2, label="sin penalización KL")
    ax.plot(pasos, cal_con, color=GOLD, lw=2.4, label="con penalización KL")
    ax.annotate("reward hacking:\nel modelo ha encontrado\ncómo engañar al RM",
                (80, 0.30), (38, 0.52), fontsize=8.6, color=MUTE,
                arrowprops=dict(arrowstyle="-|>", color=MUTE, lw=1.1))
    ax.set_xlabel("pasos de optimización")
    ax.set_ylabel("calidad real juzgada por un humano")
    ax.set_title("La calidad real se hunde sin el freno", fontsize=11.5,
                 fontweight="bold", pad=12)
    ax.legend(fontsize=8.6, frameon=False, loc="lower left")
    ax.set_ylim(0, 1.05)
    ax.tick_params(labelsize=9)

    fig.suptitle(r"Por qué toda la familia RLHF lleva el término  $-\beta\,\mathrm{KL}(\pi_\theta \,\|\, \pi_{ref})$",
                 fontsize=12.5, fontweight="bold", y=1.06)
    fig.text(0.5, 0.985, "curvas esquemáticas dibujadas a mano para ilustrar el fenómeno, no medidas experimentales",
             ha="center", fontsize=8.2, color=MUTE, style="italic")
    fig.tight_layout()
    F.save(fig, AQUI / "05_kl.png")


# ==========================================================================

FIGURAS = [fig_mapa, fig_quien_usa_que, fig_rag_flujo, fig_ventana,
           fig_mcp_arquitectura, fig_mcp_secuencia, fig_sft_mascara,
           fig_sft_fases, fig_lora_descomposicion, fig_lora_coste,
           fig_rlhf_etapas, fig_bradley_terry, fig_kl]


def main() -> None:
    for fn in FIGURAS:
        fn()
        print(f"  ok  {fn.__name__}")
    print(f"\n{len(FIGURAS)} figuras en {AQUI}")


if __name__ == "__main__":
    main()
