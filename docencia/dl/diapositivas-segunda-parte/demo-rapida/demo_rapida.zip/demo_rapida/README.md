# Demo rápida: las cinco cosas que se le hacen a un modelo de lenguaje

**Deep Learning para Business Analytics — Comillas ICADE**

Seis cuadernos de Jupyter que cogen un modelo de pesos abiertos y le aplican, en orden, RAG, MCP,
SFT, LoRA y RLHF. Todo corre en un portátil sin GPU. Todo el código se ejecuta de verdad: no hay
resultados pegados ni pseudocódigo.

Los seis comparten una historia. Trabajamos para **Banco Iberia**, un banco inventado con su
normativa, sus clientes y su buzón de incidencias. Que esté inventado es lo que hace la demo
honesta: ningún modelo del mundo ha visto estos documentos durante el preentrenamiento, así que
cuando acierta una cifra es porque la ha leído, no porque la recuerde.

---

## Los cuadernos

| | Fichero | Qué se hace | ¿Se tocan los pesos? | Tiempo en CPU |
|---|---|---|---|---|
| 00 | `00_el_modelo.ipynb` | descargar un modelo libre y abrirlo por dentro | — | ~3 min |
| 01 | `01_rag.ipynb` | responder leyendo los documentos de la empresa | no | ~8 min |
| 02 | `02_mcp.ipynb` | darle herramientas que ejecutan código de verdad | no | ~8 min |
| 03 | `03_sft.ipynb` | enseñarle una tarea con 160 ejemplos resueltos | sí, todos | ~10 min |
| 04 | `04_lora.ipynb` | lo mismo moviendo el 3,5 % de los pesos | sí, unos pocos | ~10 min |
| 05 | `05_rlhf.ipynb` | moverlo hacia lo que las personas prefieren | sí, con un juez aprendido | ~15 min |

Empieza por el 00. Los demás se pueden leer en cualquier orden, salvo el 04, que compara sus
resultados con los del 03.

---

## Instalación

```bash
pip install torch transformers sentence-transformers peft accelerate faiss-cpu \
            scikit-learn matplotlib huggingface_hub
```

Opcionales:

```bash
pip install "mcp[cli]"      # solo para el servidor del cuaderno 02 con el SDK oficial
pip install bitsandbytes    # solo para QLoRA, y requiere CUDA
```

**Hardware.** Está preparado para CPU con unos **6 GB de RAM libres**. Si tienes el navegador con
cuarenta pestañas abiertas, ciérralas: los cuadernos 03, 04 y 05 llegan a picos de 5,3 GB y el
sistema mata el proceso sin avisar. Con GPU no hay que cambiar nada, el código detecta el
dispositivo solo.

Los tiempos de la tabla están medidos en un portátil con 8 hilos de CPU y sin GPU. La primera
ejecución añade la descarga de los modelos (unos 3,7 GB en total), que se cachean en
`~/.cache/huggingface`.

---

## Los modelos

Los tres son de pesos abiertos y de uso comercial libre.

| Modelo | Papel | Parámetros | Licencia |
|---|---|---|---|
| `Qwen/Qwen2.5-1.5B-Instruct` | conversa (cuadernos 01 y 02) | 1.540 M | Apache 2.0 |
| `HuggingFaceTB/SmolLM2-135M-Instruct` | se entrena (03, 04, 05) | 135 M | Apache 2.0 |
| `intfloat/multilingual-e5-small` | vectoriza texto (01) | 118 M | MIT |

Para cambiarlos, toca `comun/config.py` y nada más.

---

## Qué hay en cada carpeta

```
demo_rapida/
├── 00_el_modelo.ipynb …… 05_rlhf.ipynb    los cuadernos
├── comun/
│   ├── config.py          modelos, semillas, dispositivo, helpers
│   ├── corpus.py          la normativa de Banco Iberia (16 fragmentos + 6 preguntas)
│   ├── datos.py           los conjuntos de triaje y de preferencias
│   └── entrenamiento.py   tokenización con máscara, generación, métricas, log-probs
├── mcp_demo/
│   ├── servidor_mcp.py      servidor MCP a mano, sin dependencias, 200 líneas
│   ├── servidor_fastmcp.py  el mismo con el SDK oficial, para Claude Desktop
│   └── cliente_mcp.py       cliente MCP sobre stdio, con traza del protocolo
├── figs/
│   ├── make_figs.py       genera las 13 figuras
│   └── *.png
└── notebooks_build/
    ├── build_0*.py        las celdas de cada cuaderno, en Python legible
    ├── build_todo.py      regenera los seis .ipynb
    └── publicar.py        prepara HTML con salidas, .ipynb limpios y el zip para la web
```

---

## Para el profesor

Los cuadernos no se editan a mano. Se editan los `notebooks_build/build_0*.py`, que son ficheros
Python legibles con la lista de celdas, y se regeneran:

```bash
cd demo_rapida
python3 notebooks_build/build_todo.py      # los seis cuadernos
python3 figs/make_figs.py                  # las figuras
```

La razón es prosaica: un `.ipynb` es JSON con el código escapado dentro de listas de cadenas, y su
diff no se lee. El `build_*.py` sí.

Los cuadernos se publican **sin salidas ejecutadas**, para que el alumno vea el resultado
aparecer. Para comprobar que siguen corriendo después de un cambio, y para generar la versión con
salidas que se publica en la web:

```bash
# ejecuta el cuaderno dejando una copia _run_*.ipynb con las salidas
cp 01_rag.ipynb _run_01_rag.ipynb
jupyter nbconvert --execute --to notebook --inplace _run_01_rag.ipynb

# y, con los seis _run_*.ipynb al día, prepara lo que va a la web:
# HTML con resultados, .ipynb limpios, figs/ y el zip completo
python3 notebooks_build/publicar.py
```

Ningún número de la prosa debe sobrevivir a una ejecución que lo contradiga. Si cambias el modelo,
los datos o los hiperparámetros, vuelve a ejecutar y reescribe las cifras del texto.

---

## Prueba rápida de que todo está en su sitio

```bash
cd demo_rapida
python3 mcp_demo/cliente_mcp.py            # el servidor MCP responde
python3 -c "from comun.config import resumen_entorno; resumen_entorno()"
python3 -c "from comun.datos import triaje; print(len(triaje()[0]), 'ejemplos')"
```

---

## Qué NO está en esta demo

Lo digo porque la frontera importa y porque son las preguntas que caen en clase:

- **Preentrenamiento.** Aquí se parte siempre de un modelo ya entrenado. Entrenar uno desde cero
  cuesta millones de euros y no cabe en un cuaderno.
- **PPO de verdad.** El cuaderno 05 entrena el modelo de recompensa, hace DPO y ejecuta un bucle
  de policy gradient (REINFORCE con penalización KL) que sirve para ver el *reward hacking* en
  dos minutos. El recorte y las varias épocas por lote que distinguen a PPO de REINFORCE se
  explican y se dejan como ejercicio: ejecutarlos con un presupuesto que converja pide GPU.
- **Despliegue.** Nada de servidores de inferencia (vLLM, TGI), cuantización en producción,
  *batching* dinámico ni monitorización. Es otro curso.
- **Evaluación seria.** Los conjuntos de prueba tienen entre 5 y 40 ejemplos. Sirven para ver el
  efecto, no para tomar una decisión. Cada cuaderno dice en voz alta dónde su número no se sostiene.
