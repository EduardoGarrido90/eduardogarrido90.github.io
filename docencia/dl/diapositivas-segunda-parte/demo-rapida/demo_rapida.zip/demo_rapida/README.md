# Demo rápida: las cuatro cosas que se le hacen a un modelo de lenguaje

**Deep Learning para Business Analytics — Comillas ICADE**

Cinco cuadernos de Jupyter que cogen un modelo de pesos abiertos y le aplican, en orden, RAG, MCP,
SFT y LoRA. Todo corre en un portátil sin GPU. Todo el código se ejecuta de verdad: no hay
resultados pegados ni pseudocódigo.

Hay un sexto cuaderno, `05_rlhf.ipynb`, que **no forma parte del material publicado**: RLHF se
queda fuera del temario de este curso. Sigue en el repositorio y funciona, pero pide 7 GB de RAM
y no viaja en el zip de los alumnos. Para reincorporarlo, añádelo a `CUADERNOS` en
`notebooks_build/publicar.py`.

Los cinco comparten una historia. Trabajamos para **Banco Iberia**, un banco inventado con su
normativa, sus clientes y su buzón de incidencias. Que esté inventado es lo que hace la demo
honesta: ningún modelo del mundo ha visto estos documentos durante el preentrenamiento, así que
cuando acierta una cifra es porque la ha leído, no porque la recuerde.

---

## Los cuadernos

| | Fichero | Qué se hace | ¿Se tocan los pesos? | Tiempo en CPU | Pico de RAM |
|---|---|---|---|---|---|
| 00 | `00_el_modelo.ipynb` | descargar un modelo libre y abrirlo por dentro | — | ~1 min | 4,1 GB |
| 01 | `01_rag.ipynb` | responder leyendo los documentos de la empresa | no | ~3 min | 4,6 GB |
| 02 | `02_mcp.ipynb` | darle herramientas que ejecutan código de verdad | no | ~10 min | 4,0 GB |
| 03 | `03_sft.ipynb` | enseñarle una tarea con 160 ejemplos resueltos | sí, todos | ~6 min | 4,8 GB |
| 04 | `04_lora.ipynb` | lo mismo moviendo el 3,5 % de los pesos | sí, unos pocos | ~6 min | 5,6 GB |
| 05 | `05_rlhf.ipynb` *(no publicado)* | moverlo hacia lo que las personas prefieren | sí, con un juez aprendido | ~15 min | 7,0 GB |

Los tiempos y los picos están medidos con `/usr/bin/time` sobre la ejecución completa de cada
cuaderno, en un portátil Linux con 8 hilos, sin GPU y con los modelos ya en caché.

Empieza por el 00. Los demás se pueden leer en cualquier orden, salvo el 04, que compara sus
resultados con los del 03.

---

## Instalación

**No hay que instalar nada a mano.** La primera celda de cualquiera de los cuadernos mira qué
sistema operativo tienes, comprueba qué falta y lo baja. Funciona igual en Windows, en macOS y en
Linux, y también en Google Colab. Se puede ejecutar las veces que haga falta: si ya está todo, no
hace nada.

Lo único que hay que tener antes es **Python y Jupyter**, que son los que abren el cuaderno:

| Sistema | Cómo se instala Python | Cómo se abre el cuaderno |
|---|---|---|
| Windows | desde [python.org](https://www.python.org/downloads/windows/), marcando «Add Python to PATH» | `py -m pip install notebook` y luego `py -m notebook` |
| macOS | desde [python.org](https://www.python.org/downloads/macos/) o `brew install python` | `python3 -m pip install notebook` y luego `python3 -m notebook` |
| Linux | `sudo apt install python3 python3-pip python3-venv` | `python3 -m pip install notebook` y luego `python3 -m notebook` |

Descomprime el zip entero y abre el cuaderno **desde dentro de la carpeta `demo_rapida`**: los
cuadernos importan `comun/` y lanzan `mcp_demo/`, así que un `.ipynb` suelto no funciona.

**En Google Colab**, sube el zip y descomprímelo en una celda antes de abrir el cuaderno:

```python
!unzip -q demo_rapida.zip
```

Colab ya trae PyTorch, así que la celda de instalación no lo toca y termina en segundos.

**Versiones de Python.** Vale de la 3.10 a la 3.13. Hay una excepción: en un **Mac con procesador
Intel**, PyTorch dejó de publicar versiones después de la 2.2.2, y esa solo llega hasta Python
3.11. Si ese es tu caso, instala Python 3.11 o usa Google Colab. El cuaderno lo detecta y lo dice.

**Hardware.** Todo va en CPU y los cinco cuadernos publicados caben en **5 GB de RAM libres**. Si
tienes el navegador con cuarenta pestañas abiertas, ciérralas: cuando el sistema se queda sin
memoria mata el kernel sin avisar y Jupyter solo dice «Kernel died». Con GPU no hay que cambiar
nada, el código detecta el dispositivo solo. El cuaderno 05, el que no se publica, pide 7 GB.

La primera ejecución añade la descarga de los modelos (unos 3,7 GB en total), que se guardan en la
caché de Hugging Face (`~/.cache/huggingface`, o `C:\Users\tu_usuario\.cache\huggingface` en
Windows) y no se vuelven a bajar.

### Si algo falla

| Síntoma | Qué hacer |
|---|---|
| La celda de instalación da error | Ejecútala como `instalar(verboso=True)`: imprime el plan y la salida completa de pip. |
| `ModuleNotFoundError` justo después de instalar | Reinicia el kernel (menú *Kernel → Restart*) y vuelve a ejecutar la primera celda. |
| «No encuentro la carpeta `comun`» | Has abierto un `.ipynb` suelto. Descomprime el zip entero y ábrelo desde dentro de `demo_rapida`. |
| El cuaderno 01 dice que FAISS no está disponible | No pasa nada: hace el mismo cálculo con numpy y los números no cambian. |

Opcionales, para quien quiera ir más allá:

```bash
pip install "mcp[cli]"      # solo para el servidor del cuaderno 02 con el SDK oficial
pip install bitsandbytes    # solo para QLoRA, y requiere CUDA
```

---

## Los modelos

Los tres son de pesos abiertos y de uso comercial libre.

| Modelo | Papel | Parámetros | Licencia |
|---|---|---|---|
| `Qwen/Qwen2.5-1.5B-Instruct` | conversa (cuadernos 01 y 02) | 1.540 M | Apache 2.0 |
| `HuggingFaceTB/SmolLM2-135M-Instruct` | se entrena (03 y 04) | 135 M | Apache 2.0 |
| `intfloat/multilingual-e5-small` | vectoriza texto (01) | 118 M | MIT |

Para cambiarlos, toca `comun/config.py` y nada más.

---

## Qué hay en cada carpeta

```
demo_rapida/
├── 00_el_modelo.ipynb …… 04_lora.ipynb    los cuadernos que se publican
├── 05_rlhf.ipynb                      RLHF, fuera del temario de este curso
├── comun/
│   ├── entorno.py         detecta el sistema e instala lo que falte (primera celda)
│   ├── config.py          modelos, semillas, dispositivo, helpers
│   ├── corpus.py          la normativa de Banco Iberia (16 fragmentos + 6 preguntas)
│   ├── datos.py           los conjuntos de triaje y de preferencias
│   └── entrenamiento.py   tokenización con máscara, generación, métricas, log-probs
├── mcp_demo/
│   ├── servidor_mcp.py      servidor MCP a mano, sin dependencias, 200 líneas
│   ├── servidor_fastmcp.py  el mismo con el SDK oficial, para Claude Desktop
│   └── cliente_mcp.py       cliente MCP sobre stdio, con traza del protocolo
├── figs/
│   ├── make_figs.py       genera las 13 figuras
│   └── *.png
└── notebooks_build/
    ├── build_0*.py           las celdas de cada cuaderno, en Python legible
    ├── build_todo.py         regenera los seis .ipynb (incluido el 05)
    ├── test_entorno.py       prueba las ramas de Windows, macOS y Linux desde aquí
    ├── comprobar_ruedas.py   pregunta a PyPI si hay rueda para los cuatro sistemas
    └── publicar.py           prepara HTML con salidas, .ipynb limpios y el zip para la web
```

---

## Para el profesor

Los cuadernos no se editan a mano. Se editan los `notebooks_build/build_0*.py`, que son ficheros
Python legibles con la lista de celdas, y se regeneran:

```bash
cd demo_rapida
python3 notebooks_build/build_todo.py      # los seis cuadernos del repositorio
python3 figs/make_figs.py                  # las figuras
```

La razón es prosaica: un `.ipynb` es JSON con el código escapado dentro de listas de cadenas, y su
diff no se lee. El `build_*.py` sí.

Los cuadernos se publican **sin salidas ejecutadas**, para que el alumno vea el resultado
aparecer. Para comprobar que siguen corriendo después de un cambio, y para generar la versión con
salidas que se publica en la web:

```bash
# ejecuta el cuaderno dejando una copia _run_*.ipynb con las salidas
cp 01_rag.ipynb _run_01_rag.ipynb
jupyter nbconvert --execute --to notebook --inplace _run_01_rag.ipynb

# y, con los _run_*.ipynb de los cuadernos publicables al día, prepara la web:
# HTML con resultados, .ipynb limpios, figs/ y el zip completo
python3 notebooks_build/publicar.py
```

Ningún número de la prosa debe sobrevivir a una ejecución que lo contradiga. Si cambias el modelo,
los datos o los hiperparámetros, vuelve a ejecutar y reescribe las cifras del texto.

---

## Prueba rápida de que todo está en su sitio

```bash
cd demo_rapida
python3 mcp_demo/cliente_mcp.py            # el servidor MCP responde
python3 -c "from comun.config import resumen_entorno; resumen_entorno()"
python3 -c "from comun.datos import triaje; print(len(triaje()[0]), 'ejemplos')"
python3 -m pytest notebooks_build/test_entorno.py -q    # las ramas de cada sistema
python3 notebooks_build/comprobar_ruedas.py             # ¿siguen existiendo las ruedas?
```

`comprobar_ruedas.py` conviene pasarlo cada curso antes de publicar: los paquetes retiran ruedas y
suben el mínimo de macOS sin avisar, y el aula no es el sitio donde enterarse.

---

## Qué NO está en esta demo

Lo digo porque la frontera importa y porque son las preguntas que caen en clase:

- **Preentrenamiento.** Aquí se parte siempre de un modelo ya entrenado. Entrenar uno desde cero
  cuesta millones de euros y no cabe en un cuaderno.
- **RLHF.** Queda fuera del temario de este curso. El cuaderno 05 sigue en el repositorio, con el
  modelo de recompensa, DPO y un bucle de policy gradient que enseña el *reward hacking* en dos
  minutos, pero no se publica ni se da en clase.
- **Despliegue.** Nada de servidores de inferencia (vLLM, TGI), cuantización en producción,
  *batching* dinámico ni monitorización. Es otro curso.
- **Evaluación seria.** Los conjuntos de prueba tienen entre 5 y 40 ejemplos. Sirven para ver el
  efecto, no para tomar una decisión. Cada cuaderno dice en voz alta dónde su número no se sostiene.
