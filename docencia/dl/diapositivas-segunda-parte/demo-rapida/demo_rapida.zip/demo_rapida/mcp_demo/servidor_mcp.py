#!/usr/bin/env python3
"""Servidor MCP de Banco Iberia, escrito a mano y sin dependencias.

MCP (Model Context Protocol) es un protocolo para que un modelo de lenguaje
pueda usar herramientas que viven fuera de él. Por dentro no hay magia: es
JSON-RPC 2.0, un mensaje JSON por línea, hablando por la entrada y la salida
estándar del proceso.

Lo escribimos a mano justamente para que se vea. En producción se usa el SDK
oficial (`pip install mcp`, ver `servidor_fastmcp.py`), que hace esto mismo en
diez líneas, pero entonces el protocolo queda tapado.

Ciclo de vida de una sesión:

    cliente -> initialize                       "hola, hablo la versión X"
    cliente <- resultado con capabilities       "hola, yo también, y sé hacer esto"
    cliente -> notifications/initialized        "listo" (notificación: sin respuesta)
    cliente -> tools/list                       "¿qué herramientas tienes?"
    cliente <- lista con el esquema JSON de cada una
    cliente -> tools/call                       "ejecuta esta con estos argumentos"
    cliente <- contenido del resultado

Arráncalo suelto para hablar con él a mano (`python` en Windows, `python3` en
macOS y Linux):

    $ python3 servidor_mcp.py
    {"jsonrpc":"2.0","id":1,"method":"tools/list"}
"""

from __future__ import annotations

import json
import sys
from typing import Any, Callable

PROTOCOL_VERSION = "2024-11-05"

# El cable del protocolo es texto JSON con acentos, y aquí se habla castellano.
# Un proceso Python lanzado desde Jupyter en Windows no escribe en UTF-8: usa
# la página ANSI del sistema (cp1252 en una instalación española), donde «ó» es
# el byte 0xF3. El cliente lee UTF-8, 0xF3 no es UTF-8 válido, y la sesión
# muere con UnicodeDecodeError en la primera respuesta que lleve una tilde.
# Esto fija UTF-8 en los dos extremos pase lo que pase, incluso cuando quien
# arranca el servidor es Claude Desktop y no nuestro cliente.
for _flujo in (sys.stdin, sys.stdout, sys.stderr):
    if hasattr(_flujo, "reconfigure"):
        _flujo.reconfigure(encoding="utf-8", errors="replace")

# --------------------------------------------------------------------------
# La "base de datos" del banco. En un servidor real, aquí habría una conexión
# al core bancario. El modelo nunca ve esto: solo ve lo que devuelven las
# herramientas, y solo cuando las llama.
# --------------------------------------------------------------------------

CLIENTES: dict[str, dict[str, Any]] = {
    "IB-1001": {"nombre": "Lucía Ferrer", "saldo": 4820.55, "tarjeta": "Premium",
                "nomina": 2400.0, "perfil_mifid": "moderado"},
    "IB-1002": {"nombre": "Diego Nadal", "saldo": -312.40, "tarjeta": "Clásica",
                "nomina": 1650.0, "perfil_mifid": "conservador"},
    "IB-1003": {"nombre": "Alba Reixach", "saldo": 128340.10, "tarjeta": "Premium",
                "nomina": 5100.0, "perfil_mifid": "dinámico"},
}

NORMATIVA: dict[str, str] = {
    "hipoteca": "Hasta el 80 % del valor de tasación en vivienda habitual. La cuota "
                "no puede superar el 35 % de los ingresos netos. Plazo máximo 30 años. "
                "Tipo fijo de referencia 3,10 % TAE con nómina domiciliada.",
    "tarjeta": "Clásica: 36 €/año, exenta facturando más de 3.000 €/año. "
               "Premium: 180 €/año con seguro de viaje de hasta 500.000 €.",
    "fraude": "Plazo de reclamación: 13 meses desde el cargo. Abono provisional en "
              "10 días hábiles. Importes por encima de 3.000 € se escalan a "
              "Investigación Financiera en menos de 4 horas.",
    "cuenta": "Cuenta Nómina sin comisión con nómina de 700 €/mes o dos recibos. "
              "En otro caso, 60 €/año. Descubierto al 18 % nominal anual.",
    "inversion": "Test MiFID II obligatorio, validez 24 meses. Gama indexada con "
                 "0,32 % de comisión de gestión, mínimo inicial de 500 €.",
}


# --------------------------------------------------------------------------
# Las herramientas. Cada una es una función Python normal más un esquema JSON
# que le dice al modelo cómo se llama, para qué sirve y qué argumentos lleva.
# Ese esquema es lo único que el modelo ve antes de decidir si la usa.
# --------------------------------------------------------------------------

HERRAMIENTAS: list[dict[str, Any]] = []
IMPLEMENTACIONES: dict[str, Callable[..., str]] = {}


def herramienta(nombre: str, descripcion: str, esquema: dict[str, Any]):
    """Decorador que registra una función como herramienta MCP."""
    def envoltorio(fn: Callable[..., str]) -> Callable[..., str]:
        HERRAMIENTAS.append({"name": nombre, "description": descripcion,
                             "inputSchema": esquema})
        IMPLEMENTACIONES[nombre] = fn
        return fn
    return envoltorio


@herramienta(
    "consultar_cliente",
    "Devuelve el saldo, la nómina, el tipo de tarjeta y el perfil MiFID de un "
    "cliente de Banco Iberia a partir de su identificador (formato IB-dddd).",
    {"type": "object",
     "properties": {"cliente_id": {"type": "string",
                                   "description": "Identificador, por ejemplo IB-1001"}},
     "required": ["cliente_id"]},
)
def consultar_cliente(cliente_id: str) -> str:
    c = CLIENTES.get(cliente_id.strip().upper())
    if c is None:
        return (f"No existe ningún cliente con identificador {cliente_id}. "
                f"Identificadores válidos: {', '.join(CLIENTES)}.")
    return (f"{c['nombre']} ({cliente_id}): saldo {c['saldo']:.2f} €, "
            f"nómina {c['nomina']:.2f} €/mes, tarjeta {c['tarjeta']}, "
            f"perfil MiFID {c['perfil_mifid']}.")


@herramienta(
    "calcular_cuota_hipoteca",
    "Calcula la cuota mensual de un préstamo hipotecario francés y el total de "
    "intereses pagados a lo largo de la vida del préstamo.",
    {"type": "object",
     "properties": {
         "capital": {"type": "number", "description": "Importe prestado en euros"},
         "anios": {"type": "integer", "description": "Plazo de amortización en años"},
         "tae": {"type": "number", "description": "Tipo de interés anual en tanto por ciento, p. ej. 3.10"}},
     "required": ["capital", "anios", "tae"]},
)
def calcular_cuota_hipoteca(capital: float, anios: int, tae: float) -> str:
    """Sistema francés: cuota constante c = C · i / (1 - (1+i)^-n)."""
    if capital <= 0 or anios <= 0 or tae < 0:
        return "Argumentos inválidos: capital y años deben ser positivos y el tae no negativo."
    n = int(anios) * 12
    i = float(tae) / 100.0 / 12.0
    cuota = capital / n if i == 0 else capital * i / (1 - (1 + i) ** (-n))
    intereses = cuota * n - capital
    return (f"Cuota mensual: {cuota:.2f} €. Pagos: {n}. "
            f"Intereses totales: {intereses:.2f} €. Total devuelto: {cuota * n:.2f} €.")


@herramienta(
    "buscar_normativa",
    "Consulta las condiciones de Banco Iberia: precios, cuotas anuales, comisiones, "
    "plazos de reclamacion, limites de concesion y requisitos. Usala SIEMPRE que la "
    "pregunta mencione cuanto cuesta algo, una comision, un plazo, un limite o un "
    "requisito. El argumento 'tema' debe ser uno de: hipoteca, tarjeta, fraude, "
    "cuenta, inversion.",
    {"type": "object",
     "properties": {"tema": {"type": "string",
                             "description": "Uno de: hipoteca, tarjeta, fraude, cuenta, inversion",
                             "enum": ["hipoteca", "tarjeta", "fraude", "cuenta", "inversion"]}},
     "required": ["tema"]},
)
def buscar_normativa(tema: str) -> str:
    t = tema.strip().lower()
    if t in NORMATIVA:
        return NORMATIVA[t]
    # Búsqueda laxa: el modelo puede pedir "hipotecas" o "préstamo hipotecario".
    for clave, texto in NORMATIVA.items():
        if clave in t or t in texto.lower():
            return texto
    return f"No hay normativa sobre '{tema}'. Temas disponibles: {', '.join(NORMATIVA)}."


# --------------------------------------------------------------------------
# La capa JSON-RPC. Tres métodos y una notificación es todo lo que hace falta
# para un servidor MCP que solo expone herramientas.
# --------------------------------------------------------------------------

def manejar(peticion: dict[str, Any]) -> dict[str, Any] | None:
    """Traduce una petición JSON-RPC en su respuesta. Devuelve None para las
    notificaciones, que por definición no llevan respuesta."""
    metodo = peticion.get("method")
    pid = peticion.get("id")
    params = peticion.get("params") or {}

    if metodo == "initialize":
        return _ok(pid, {
            "protocolVersion": PROTOCOL_VERSION,
            "capabilities": {"tools": {"listChanged": False}},
            "serverInfo": {"name": "banco-iberia", "version": "1.0.0"},
        })

    if metodo in ("notifications/initialized", "initialized"):
        return None

    if metodo == "tools/list":
        return _ok(pid, {"tools": HERRAMIENTAS})

    if metodo == "tools/call":
        nombre = params.get("name")
        args = params.get("arguments") or {}
        fn = IMPLEMENTACIONES.get(nombre)
        if fn is None:
            return _error(pid, -32602, f"Herramienta desconocida: {nombre}")
        try:
            salida = fn(**args)
        except TypeError as e:
            # Argumentos que no encajan con la firma. En MCP esto NO es un error
            # de protocolo: se devuelve como resultado con isError, para que el
            # modelo lo lea y pueda corregirse en el siguiente turno.
            return _ok(pid, {"content": [{"type": "text", "text": f"Argumentos incorrectos: {e}"}],
                             "isError": True})
        except Exception as e:  # noqa: BLE001 - el servidor no debe morirse nunca
            return _ok(pid, {"content": [{"type": "text", "text": f"Error ejecutando {nombre}: {e}"}],
                             "isError": True})
        return _ok(pid, {"content": [{"type": "text", "text": salida}], "isError": False})

    if metodo == "ping":
        return _ok(pid, {})

    return _error(pid, -32601, f"Método no implementado: {metodo}")


def _ok(pid: Any, resultado: dict[str, Any]) -> dict[str, Any]:
    return {"jsonrpc": "2.0", "id": pid, "result": resultado}


def _error(pid: Any, codigo: int, mensaje: str) -> dict[str, Any]:
    return {"jsonrpc": "2.0", "id": pid, "error": {"code": codigo, "message": mensaje}}


def main() -> None:
    """Bucle principal: una línea de entrada, una línea de salida.

    Nada se imprime en stdout que no sea JSON-RPC. Los avisos van a stderr,
    porque stdout es el cable del protocolo y un `print` de depuración ahí
    rompe la sesión. Es el error número uno al escribir servidores MCP.
    """
    for linea in sys.stdin:
        linea = linea.strip()
        if not linea:
            continue
        try:
            peticion = json.loads(linea)
        except json.JSONDecodeError as e:
            print(json.dumps(_error(None, -32700, f"JSON inválido: {e}")), flush=True)
            continue
        respuesta = manejar(peticion)
        if respuesta is not None:
            print(json.dumps(respuesta, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
