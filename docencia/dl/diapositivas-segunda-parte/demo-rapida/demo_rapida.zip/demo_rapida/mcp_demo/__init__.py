"""Servidor y cliente MCP de la demo, importables como `mcp_demo.<modulo>`."""
