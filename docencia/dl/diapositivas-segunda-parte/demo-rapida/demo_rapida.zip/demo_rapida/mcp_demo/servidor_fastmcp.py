#!/usr/bin/env python3
"""El mismo servidor MCP, ahora con el SDK oficial.

    pip install "mcp[cli]"
    python3 servidor_fastmcp.py

Compara este fichero con `servidor_mcp.py`. Hacen exactamente lo mismo. La
diferencia es que aquí el JSON-RPC, el apretón de manos y la generación del
esquema de cada herramienta a partir de los type hints los pone el SDK. Esa es
la versión que escribirías en el trabajo; la otra es la que hay que leer una
vez para saber qué está pasando debajo.

Para enchufarlo a Claude Desktop o a Claude Code, añade a la configuración de
servidores MCP:

    {
      "mcpServers": {
        "banco-iberia": {
          "command": "python3",
          "args": ["/ruta/absoluta/a/demo_rapida/mcp_demo/servidor_fastmcp.py"]
        }
      }
    }

En Claude Code la vía corta es:

    claude mcp add banco-iberia -- python3 /ruta/absoluta/.../servidor_fastmcp.py
"""

from __future__ import annotations

from mcp.server.fastmcp import FastMCP

from servidor_mcp import CLIENTES, NORMATIVA

mcp = FastMCP("banco-iberia")


@mcp.tool()
def consultar_cliente(cliente_id: str) -> str:
    """Devuelve el saldo, la nómina, el tipo de tarjeta y el perfil MiFID de un
    cliente de Banco Iberia a partir de su identificador (formato IB-dddd)."""
    c = CLIENTES.get(cliente_id.strip().upper())
    if c is None:
        return (f"No existe ningún cliente con identificador {cliente_id}. "
                f"Identificadores válidos: {', '.join(CLIENTES)}.")
    return (f"{c['nombre']} ({cliente_id}): saldo {c['saldo']:.2f} €, "
            f"nómina {c['nomina']:.2f} €/mes, tarjeta {c['tarjeta']}, "
            f"perfil MiFID {c['perfil_mifid']}.")


@mcp.tool()
def calcular_cuota_hipoteca(capital: float, anios: int, tae: float) -> str:
    """Calcula la cuota mensual de un préstamo hipotecario francés y el total de
    intereses pagados a lo largo de la vida del préstamo.

    Args:
        capital: importe prestado en euros.
        anios: plazo de amortización en años.
        tae: tipo de interés anual en tanto por ciento, por ejemplo 3.10.
    """
    if capital <= 0 or anios <= 0 or tae < 0:
        return "Argumentos inválidos: capital y años deben ser positivos y el tae no negativo."
    n = int(anios) * 12
    i = tae / 100.0 / 12.0
    cuota = capital / n if i == 0 else capital * i / (1 - (1 + i) ** (-n))
    intereses = cuota * n - capital
    return (f"Cuota mensual: {cuota:.2f} €. Pagos: {n}. "
            f"Intereses totales: {intereses:.2f} €. Total devuelto: {cuota * n:.2f} €.")


@mcp.tool()
def buscar_normativa(tema: str) -> str:
    """Busca en la normativa interna de Banco Iberia por tema. Temas disponibles:
    hipoteca, tarjeta, fraude, cuenta, inversion."""
    t = tema.strip().lower()
    if t in NORMATIVA:
        return NORMATIVA[t]
    for clave, texto in NORMATIVA.items():
        if clave in t or t in texto.lower():
            return texto
    return f"No hay normativa sobre '{tema}'. Temas disponibles: {', '.join(NORMATIVA)}."


if __name__ == "__main__":
    mcp.run(transport="stdio")
