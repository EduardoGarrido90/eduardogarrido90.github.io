#!/usr/bin/env python3
"""Cliente MCP mínimo: lanza el servidor como subproceso y le habla por stdio.

En la arquitectura de MCP hay tres papeles:

    HOST      la aplicación que el usuario ve (Claude Desktop, un IDE, tu app)
    CLIENTE   la pieza del host que mantiene UNA sesión con UN servidor
    SERVIDOR  el proceso que expone herramientas, recursos y prompts

Esta clase es el CLIENTE. El HOST será el cuaderno 02, que además pone el
modelo de lenguaje. El SERVIDOR es `servidor_mcp.py`.

Uso, desde cualquier sistema operativo:

    from comun.entorno import comando_servidor

    with ClienteMCP(comando_servidor()) as c:
        print(c.listar_herramientas())
        print(c.llamar("calcular_cuota_hipoteca", {"capital": 192000, "anios": 30, "tae": 3.1}))

`comando_servidor()` devuelve el argv correcto: el intérprete que mueve el
cuaderno (`python3` no existe en Windows), la ruta absoluta del servidor y
UTF-8 forzado.
"""

from __future__ import annotations

import json
import subprocess
import sys
from typing import Any

PROTOCOL_VERSION = "2024-11-05"

# Cuánto se espera a que el servidor cierre por las buenas antes de matarlo.
ESPERA_CIERRE_S = 5


def _entorno_hijo() -> dict[str, str]:
    """Entorno del proceso servidor, con UTF-8 forzado.

    Se replica aquí en lugar de importarlo de `comun.entorno` para que este
    fichero siga siendo legible y ejecutable por separado, que es lo que hace
    el alumno cuando lo abre para ver qué hay dentro.
    """
    import os
    env = dict(os.environ)
    env["PYTHONUTF8"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"
    return env


class ErrorMCP(RuntimeError):
    """El servidor ha devuelto un error de protocolo JSON-RPC."""


class ClienteMCP:
    """Sesión MCP sobre stdio contra un servidor arrancado como subproceso.

    Atributos:
        comando: argv del proceso servidor.
        traza: si es True, imprime cada mensaje JSON que cruza el cable. Es
            lo que hace esta demo didáctica en vez de opaca.
    """

    def __init__(self, comando: list[str], cwd: str | None = None, traza: bool = False) -> None:
        self.comando = comando
        self.cwd = cwd
        self.traza = traza
        self._siguiente_id = 0
        self.proc: subprocess.Popen[str] | None = None
        self.info_servidor: dict[str, Any] = {}

    # -- ciclo de vida ------------------------------------------------------

    def __enter__(self) -> "ClienteMCP":
        self.abrir()
        return self

    def __exit__(self, *exc: object) -> None:
        self.cerrar()

    def abrir(self) -> dict[str, Any]:
        """Arranca el servidor y completa el apretón de manos de MCP."""
        self.proc = subprocess.Popen(
            self.comando, cwd=self.cwd, env=_entorno_hijo(),
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=sys.stderr,
            text=True, bufsize=1, encoding="utf-8", errors="replace",
        )
        self.info_servidor = self._peticion("initialize", {
            "protocolVersion": PROTOCOL_VERSION,
            "capabilities": {},
            "clientInfo": {"name": "demo-rapida", "version": "1.0.0"},
        })
        self._notificacion("notifications/initialized")
        return self.info_servidor

    def cerrar(self) -> None:
        if self.proc is None:
            return
        try:
            if self.proc.stdin:
                self.proc.stdin.close()
            self.proc.wait(timeout=ESPERA_CIERRE_S)
        except subprocess.TimeoutExpired:
            self.proc.kill()
        finally:
            self.proc = None

    # -- API de alto nivel --------------------------------------------------

    def listar_herramientas(self) -> list[dict[str, Any]]:
        """Devuelve el catálogo de herramientas con su esquema JSON."""
        return self._peticion("tools/list", {})["tools"]

    def llamar(self, nombre: str, argumentos: dict[str, Any]) -> str:
        """Ejecuta una herramienta y devuelve su salida de texto concatenada."""
        r = self._peticion("tools/call", {"name": nombre, "arguments": argumentos})
        texto = "\n".join(b.get("text", "") for b in r.get("content", []) if b.get("type") == "text")
        if r.get("isError"):
            return f"[la herramienta ha fallado] {texto}"
        return texto

    def herramientas_formato_openai(self) -> list[dict[str, Any]]:
        """Traduce el catálogo MCP al formato de `tools` que esperan los chat
        templates de Qwen, Llama, Mistral y la API de OpenAI.

        Es una traducción puramente mecánica de nombres de campo. Que sea tan
        tonta es exactamente el motivo por el que MCP se ha extendido: el
        esquema de herramienta ya era de facto el mismo en todas partes, solo
        faltaba ponerse de acuerdo en cómo descubrirlo y cómo invocarlo.
        """
        return [{"type": "function",
                 "function": {"name": h["name"],
                              "description": h["description"],
                              "parameters": h["inputSchema"]}}
                for h in self.listar_herramientas()]

    # -- transporte ---------------------------------------------------------

    def _enviar(self, mensaje: dict[str, Any]) -> None:
        if self.proc is None or self.proc.stdin is None:
            raise ErrorMCP("La sesión no está abierta. Llama a abrir() primero.")
        linea = json.dumps(mensaje, ensure_ascii=False)
        if self.traza:
            print(f"  ->  {linea}")
        self.proc.stdin.write(linea + "\n")
        self.proc.stdin.flush()

    def _peticion(self, metodo: str, params: dict[str, Any]) -> dict[str, Any]:
        self._siguiente_id += 1
        pid = self._siguiente_id
        self._enviar({"jsonrpc": "2.0", "id": pid, "method": metodo, "params": params})
        assert self.proc is not None and self.proc.stdout is not None
        linea = self.proc.stdout.readline()
        if not linea:
            raise ErrorMCP(f"El servidor ha cerrado la salida sin responder a '{metodo}'.")
        if self.traza:
            print(f"  <-  {linea.strip()}")
        respuesta = json.loads(linea)
        if "error" in respuesta:
            e = respuesta["error"]
            raise ErrorMCP(f"{e.get('code')}: {e.get('message')}")
        return respuesta["result"]

    def _notificacion(self, metodo: str, params: dict[str, Any] | None = None) -> None:
        """Una notificación es una petición sin `id`: el servidor no contesta."""
        self._enviar({"jsonrpc": "2.0", "method": metodo, "params": params or {}})


if __name__ == "__main__":
    from pathlib import Path

    aqui = Path(__file__).resolve().parent
    arranque = [sys.executable, "-X", "utf8", str(aqui / "servidor_mcp.py")]
    with ClienteMCP(arranque, traza=True) as c:
        print("\nServidor:", c.info_servidor["serverInfo"], "\n")
        for h in c.listar_herramientas():
            print(f"  · {h['name']}: {h['description'][:70]}...")
        print()
        print(c.llamar("consultar_cliente", {"cliente_id": "IB-1001"}))
        print(c.llamar("calcular_cuota_hipoteca", {"capital": 192000, "anios": 30, "tae": 3.1}))
        print(c.llamar("buscar_normativa", {"tema": "fraude"}))
