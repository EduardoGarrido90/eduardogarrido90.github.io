#!/usr/bin/env python3
"""¿Existe rueda de cada dependencia para los cuatro sistemas de los alumnos?

    cd demo_rapida
    python3 notebooks_build/comprobar_ruedas.py

Herramienta del profesor. Pregunta a PyPI (y al índice de ruedas sin CUDA de
PyTorch) qué ficheros publica cada paquete dentro del rango de versiones que
fija `comun/entorno.py`, y comprueba que hay al menos uno instalable en:

    Windows x86-64          Python 3.10 a 3.13
    macOS Apple Silicon     Python 3.10 a 3.13
    macOS Intel             Python 3.10 a 3.11   (PyTorch no pasa de ahí)
    Linux x86-64            Python 3.10 a 3.13

Es una comprobación mecánica contra la fuente, no una opinión: el ordenador de
clase es Linux y no hay forma de ejecutar nada en los otros tres. Sale con
código distinto de cero si falta alguna combinación obligatoria, y así puede
correr en cualquier revisión del material antes de publicarlo.
"""

from __future__ import annotations

import json
import re
import sys
import urllib.error
import urllib.request
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from comun.entorno import (  # noqa: E402
    FAISS_MAX, FAISS_MIN, INDICE_CPU, PAQUETES, TORCH_MAC_INTEL, TORCH_MAX,
    TORCH_MIN, _en_rango,
)

TIEMPO_ESPERA = 30

# (etiqueta, patrón de plataforma en el nombre de la rueda, versiones de Python)
SISTEMAS = [
    ("Windows x86-64", r"win_amd64", ["310", "311", "312", "313"]),
    ("macOS Apple Silicon", r"macosx_\d+_\d+_arm64", ["310", "311", "312", "313"]),
    ("macOS Intel", r"macosx_\d+_\d+_(x86_64|universal2)", ["310", "311"]),
    ("Linux x86-64", r"manylinux[\w.]*_x86_64", ["310", "311", "312", "313"]),
]


def pypi(paquete: str) -> dict:
    url = f"https://pypi.org/pypi/{paquete}/json"
    with urllib.request.urlopen(url, timeout=TIEMPO_ESPERA) as r:
        return json.load(r)


def ruedas_pypi(paquete: str, minimo: str, maximo: str) -> list[str]:
    """Nombres de fichero de todas las ruedas publicadas dentro del rango."""
    datos = pypi(paquete)
    nombres = []
    for version, ficheros in datos["releases"].items():
        if not _en_rango(version, minimo, maximo):
            continue
        nombres += [f["filename"] for f in ficheros
                    if f["filename"].endswith(".whl") and not f.get("yanked")]
    return nombres


def ruedas_indice_cpu(paquete: str) -> list[str]:
    """Ruedas del índice sin CUDA de PyTorch, que es HTML y no API JSON."""
    url = f"{INDICE_CPU}/{paquete}/"
    with urllib.request.urlopen(url, timeout=TIEMPO_ESPERA) as r:
        html = r.read().decode("utf-8", "replace")
    return re.findall(r"([A-Za-z0-9_.+-]+\.whl)", html)


def hay_rueda(nombres: list[str], plataforma: str, py: str) -> bool:
    """¿Alguna de esas ruedas vale para esta plataforma y este Python?"""
    for n in nombres:
        if n.endswith("-py3-none-any.whl") or "-py2.py3-none-any" in n:
            return True            # paquete puro: sirve en todas partes
        if not re.search(plataforma, n):
            continue
        # cp311-cp311-..., cp311-abi3-..., o abi3 declarado para un cp menor
        if f"cp{py}" in n:
            return True
        encontrado = re.search(r"cp(3\d+)-abi3", n)
        if encontrado and int(encontrado.group(1)) <= int(py):
            return True
    return False


def macos_minimo(nombres: list[str], patron: str) -> str:
    """Versión de macOS más baja que admite alguna de estas ruedas.

    Importa porque una rueda `macosx_15_0_x86_64` no sirve en un Mac con
    macOS 13: pip la descarta y se pone a compilar desde fuente.
    """
    versiones = []
    for n in nombres:
        if n.endswith("-py3-none-any.whl"):
            return ""                      # paquete puro, da igual el sistema
        if re.search(patron, n):
            encontrado = re.search(r"macosx_(\d+)_(\d+)", n)
            if encontrado:
                versiones.append((int(encontrado.group(1)), int(encontrado.group(2))))
    if not versiones:
        return ""
    mayor, menor = min(versiones)
    return f"  [pide macOS {mayor}.{menor}+]"


def comprobar(titulo: str, nombres: list[str], sistemas, obligatorio: bool,
              fallos: list[str]) -> None:
    print(f"\n{titulo}")
    if not nombres:
        print("   no se ha encontrado ninguna rueda publicada")
        if obligatorio:
            fallos.append(f"{titulo}: sin ruedas")
        return
    for etiqueta, patron, pythons in sistemas:
        marcas = []
        for py in pythons:
            ok = hay_rueda(nombres, patron, py)
            marcas.append(f"3.{py[1:]}{'' if ok else ' NO'}")
            if not ok and obligatorio:
                fallos.append(f"{titulo} · {etiqueta} · Python 3.{py[1:]}")
        estado = "ok " if all("NO" not in m for m in marcas) else "FALTA"
        nota = macos_minimo(nombres, patron) if "macOS" in etiqueta else ""
        print(f"   {estado} {etiqueta:22s} {'  '.join(marcas)}{nota}")


def main() -> int:
    fallos: list[str] = []
    print("Ruedas disponibles para las dependencias de la demo.")
    print("Fuente: PyPI y el índice de ruedas sin CUDA de PyTorch.\n")

    # --- PyTorch, que es el caso difícil -----------------------------------
    try:
        comprobar(f"torch >={TORCH_MIN},<{TORCH_MAX} · PyPI "
                  "(macOS Apple Silicon y sistemas con GPU)",
                  ruedas_pypi("torch", TORCH_MIN, TORCH_MAX),
                  [s for s in SISTEMAS if "Intel" not in s[0]], True, fallos)

        comprobar(f"torch >={TORCH_MIN},<{TORCH_MAX} · índice CPU "
                  "(Windows y Linux sin GPU)",
                  [n for n in ruedas_indice_cpu("torch")
                   if _en_rango(n.split("-")[1], TORCH_MIN, TORCH_MAX)],
                  [s for s in SISTEMAS if s[0].startswith(("Windows", "Linux"))],
                  True, fallos)

        comprobar(f"torch =={TORCH_MAC_INTEL} · PyPI (Mac con Intel)",
                  [n for n in ruedas_pypi("torch", TORCH_MAC_INTEL, "99")
                   if n.split("-")[1] == TORCH_MAC_INTEL],
                  [s for s in SISTEMAS if "Intel" in s[0]], True, fallos)

        # --- El resto ------------------------------------------------------
        for nombre, minimo, maximo in PAQUETES:
            comprobar(f"{nombre} >={minimo},<{maximo}",
                      ruedas_pypi(nombre, minimo, maximo), SISTEMAS, True, fallos)

        # FAISS es opcional justo porque aquí faltan casillas: sus ruedas de
        # macOS exigen un sistema reciente. El cuaderno 01 lo sustituye solo.
        comprobar(f"faiss-cpu >={FAISS_MIN},<{FAISS_MAX}  (opcional)",
                  ruedas_pypi("faiss-cpu", FAISS_MIN, FAISS_MAX),
                  SISTEMAS, False, fallos)
    except (urllib.error.URLError, TimeoutError) as e:
        print(f"\nNo se ha podido consultar la fuente: {e}")
        return 2

    print()
    if fallos:
        print(f"FALLAN {len(fallos)} combinaciones obligatorias:")
        for f in fallos:
            print(f"   · {f}")
        return 1
    print("Todas las combinaciones obligatorias tienen rueda.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
