#!/usr/bin/env python3
"""Prepara los artefactos de la demo para la web del curso.

    cd demo_rapida
    python3 notebooks_build/publicar.py [destino]

Hace tres cosas:

1. Toma los cuadernos limpios (sin salidas) y les injerta las salidas de la
   última ejecución (`_run_*.ipynb`), emparejando celda de código por posición.
   Así el HTML publicado enseña los resultados sin que el alumno ejecute nada,
   y a la vez el .ipynb descargable va limpio.
2. Renderiza esos cuadernos con salidas a HTML con nbconvert.
3. Empaqueta la carpeta entera en un zip, que es lo único con lo que la demo
   funciona de verdad: los cuadernos importan `comun/` y lanzan `mcp_demo/`.

El destino por defecto es la carpeta de la segunda parte en el repositorio de
la web.
"""

from __future__ import annotations

import json
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
DESTINO_POR_DEFECTO = Path.home() / (
    "projects/eduardogarrido90.github.io/docencia/dl/"
    "diapositivas-segunda-parte/demo-rapida")

CUADERNOS = ["00_el_modelo", "01_rag", "02_mcp", "03_sft", "04_lora", "05_rlhf"]

# Lo que entra en el zip. Se excluye todo lo que generan los propios cuadernos.
INCLUIR = ["comun", "mcp_demo", "figs", "notebooks_build"]
EXCLUIR_SUFIJOS = {".pyc"}
EXCLUIR_DIRS = {"__pycache__", ".ipynb_checkpoints", "modelos"}


def injertar_salidas(limpio: Path, ejecutado: Path, destino: Path) -> int:
    """Copia las salidas de `ejecutado` en `limpio`, por posición de celda.

    Returns:
        número de celdas de código a las que se les ha puesto salida.
    """
    nb_l = json.loads(limpio.read_text(encoding="utf-8"))
    nb_e = json.loads(ejecutado.read_text(encoding="utf-8"))

    codigo_l = [c for c in nb_l["cells"] if c["cell_type"] == "code"]
    codigo_e = [c for c in nb_e["cells"] if c["cell_type"] == "code"]
    if len(codigo_l) != len(codigo_e):
        raise SystemExit(
            f"{limpio.name}: {len(codigo_l)} celdas de código en el cuaderno "
            f"limpio frente a {len(codigo_e)} en el ejecutado. Vuelve a "
            f"ejecutar el cuaderno antes de publicar.")

    n = 0
    for cl, ce in zip(codigo_l, codigo_e):
        cl["outputs"] = ce.get("outputs", [])
        cl["execution_count"] = ce.get("execution_count")
        n += bool(cl["outputs"])

    destino.write_text(json.dumps(nb_l, ensure_ascii=False, indent=1) + "\n",
                       encoding="utf-8")
    return n


def hacer_zip(destino: Path) -> float:
    """Empaqueta demo_rapida/ completo. Devuelve el tamaño en MB."""
    with zipfile.ZipFile(destino, "w", zipfile.ZIP_DEFLATED) as z:
        for nombre in CUADERNOS:
            z.write(RAIZ / f"{nombre}.ipynb", f"demo_rapida/{nombre}.ipynb")
        for suelto in ("README.md", "requirements.txt", ".gitignore"):
            z.write(RAIZ / suelto, f"demo_rapida/{suelto}")
        for carpeta in INCLUIR:
            for f in sorted((RAIZ / carpeta).rglob("*")):
                if not f.is_file():
                    continue
                if f.suffix in EXCLUIR_SUFIJOS:
                    continue
                if EXCLUIR_DIRS & set(f.relative_to(RAIZ).parts):
                    continue
                z.write(f, f"demo_rapida/{f.relative_to(RAIZ)}")
    return destino.stat().st_size / 1024**2


def main() -> None:
    destino = Path(sys.argv[1]) if len(sys.argv) > 1 else DESTINO_POR_DEFECTO
    destino.mkdir(parents=True, exist_ok=True)
    temporal = RAIZ / "_publicar_tmp"
    temporal.mkdir(exist_ok=True)

    print(f"Destino: {destino}\n")

    for nombre in CUADERNOS:
        limpio = RAIZ / f"{nombre}.ipynb"
        ejecutado = RAIZ / f"_run_{nombre}.ipynb"
        if not ejecutado.exists():
            raise SystemExit(
                f"falta {ejecutado.name}: ejecuta el cuaderno antes de publicar")

        con_salidas = temporal / f"{nombre}.ipynb"
        n = injertar_salidas(limpio, ejecutado, con_salidas)

        subprocess.run(
            [sys.executable, "-m", "nbconvert", "--to", "html",
             "--output-dir", str(destino), str(con_salidas)],
            check=True, capture_output=True)

        shutil.copy2(limpio, destino / f"{nombre}.ipynb")   # el .ipynb va limpio
        print(f"  {nombre}: {n} celdas con salida  ->  {nombre}.html + {nombre}.ipynb")

    shutil.rmtree(destino / "figs", ignore_errors=True)
    shutil.copytree(RAIZ / "figs", destino / "figs",
                    ignore=shutil.ignore_patterns("__pycache__", "*.py"))
    print(f"\n  figs/: {len(list((destino / 'figs').glob('*.png')))} imágenes")

    mb = hacer_zip(destino / "demo_rapida.zip")
    print(f"  demo_rapida.zip: {mb:.1f} MB")

    shutil.rmtree(temporal)
    print("\nListo.")


if __name__ == "__main__":
    main()
