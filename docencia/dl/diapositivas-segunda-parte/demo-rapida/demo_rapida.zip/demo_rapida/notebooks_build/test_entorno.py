#!/usr/bin/env python3
"""Pruebas del arranque portable. Son del profesor, no del alumno.

    cd demo_rapida
    python3 -m pytest notebooks_build/test_entorno.py -q

Lo que se comprueba aquí es la rama de cada sistema operativo. `plan_instalacion`
es una función pura: recibe la descripción de la máquina en vez de mirarla, así
que desde Linux se puede comprobar qué haría en Windows o en un Mac con Intel,
que es exactamente lo que no se puede ejecutar en esta máquina.
"""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from comun.entorno import (  # noqa: E402
    FAISS_MIN, INDICE_CPU, PAQUETES, TORCH_MAC_INTEL, TORCH_MIN,
    _en_rango, _tupla, avisos_version_python, comando_servidor, entorno_hijo,
    plan_instalacion, raiz,
)

TODO_NUEVO: dict[str, str] = {}

COMPLETO = {
    "torch": "2.9.1+cpu",
    "transformers": "4.56.2",
    "sentence-transformers": "5.1.1",
    "peft": "0.19.1",
    "accelerate": "1.10.1",
    "scikit-learn": "1.3.2",
    "matplotlib": "3.8.4",
    "numpy": "1.26.4",
    "huggingface_hub": "0.35.1",
    "faiss-cpu": "1.12.0",
}

LINUX = dict(windows=False, mac=False, mac_intel=False, colab=False, gpu=False)
LINUX_GPU = {**LINUX, "gpu": True}
WINDOWS = dict(windows=True, mac=False, mac_intel=False, colab=False, gpu=False)
WINDOWS_GPU = {**WINDOWS, "gpu": True}
MAC_ARM = dict(windows=False, mac=True, mac_intel=False, colab=False, gpu=False)
MAC_INTEL = dict(windows=False, mac=True, mac_intel=True, colab=False, gpu=False)
COLAB = dict(windows=False, mac=False, mac_intel=False, colab=True, gpu=True)


def plan(maquina: dict, presentes: dict, py=(3, 11)) -> list[dict]:
    return plan_instalacion(**maquina, version_python=py, presentes=presentes)


def args_de(ordenes: list[dict], fragmento: str) -> list[str] | None:
    """Argumentos de la primera orden que menciona `fragmento`."""
    for o in ordenes:
        if any(fragmento in a for a in o["args"]):
            return o["args"]
    return None


# -- versiones --------------------------------------------------------------

@pytest.mark.parametrize("texto,esperado", [
    ("2.9.1+cpu", (2, 9, 1)),
    ("1.26.4", (1, 26, 4)),
    ("4.56.2", (4, 56, 2)),
    ("2.2.0.post1", (2, 2, 0)),
    ("1.8", (1, 8, 0)),
    ("3", (3, 0, 0)),
    ("2.5.0rc1", (2, 5, 0)),
])
def test_tupla_de_version(texto, esperado):
    assert _tupla(texto) == esperado


def test_rango_respeta_suelo_y_techo():
    assert _en_rango("4.56.2", "4.56", "5")
    assert not _en_rango("4.55.0", "4.56", "5"), "4.55 no tiene dtype= en from_pretrained"
    assert not _en_rango("5.19.0", "4.56", "5"), "transformers 5 cambia la API y no está probado"


def test_torch_con_sufijo_local_cuenta_como_valido():
    """'2.9.1+cpu' es una versión válida de torch y no debe reinstalarse."""
    assert plan(LINUX, COMPLETO) == []


# -- una máquina en blanco, por sistema -------------------------------------

def test_linux_sin_gpu_usa_el_indice_de_cpu():
    args = args_de(plan(LINUX, TODO_NUEVO), "torch")
    assert args is not None
    assert "--index-url" in args and INDICE_CPU in args


def test_solo_con_demo_gpu_se_instala_la_version_con_cuda():
    """Por defecto, CPU. La versión con CUDA son 3 GB y un modo de fallo
    nuevo: si el driver de la máquina es más viejo que el CUDA del paquete,
    PyTorch escupe un aviso enorme y se cae a CPU igualmente."""
    for maquina in (LINUX_GPU, WINDOWS_GPU):
        assert "--index-url" not in args_de(plan(maquina, TODO_NUEVO), "torch")
    for maquina in (LINUX, WINDOWS):
        assert INDICE_CPU in args_de(plan(maquina, TODO_NUEVO), "torch")


def test_windows_sin_gpu_usa_el_indice_de_cpu():
    args = args_de(plan(WINDOWS, TODO_NUEVO), "torch")
    assert "--index-url" in args and INDICE_CPU in args


def test_mac_apple_silicon_usa_pypi_normal():
    args = args_de(plan(MAC_ARM, TODO_NUEVO), "torch")
    assert "--index-url" not in args, "el índice de CPU no publica ruedas para macOS"
    assert args[0] == f"torch>={TORCH_MIN},<3"


def test_mac_intel_se_queda_en_la_ultima_rueda_publicada():
    args = args_de(plan(MAC_INTEL, TODO_NUEVO), "torch")
    assert args == [f"torch=={TORCH_MAC_INTEL}"]


def test_colab_no_toca_torch():
    ordenes = plan(COLAB, {"torch": "2.6.0+cu124"})
    assert args_de(ordenes, "torch") is None


def test_todos_los_sistemas_instalan_el_resto_de_paquetes():
    for maquina in (LINUX, WINDOWS, MAC_ARM, MAC_INTEL, COLAB):
        ordenes = plan(maquina, TODO_NUEVO)
        pedidos = {a.split(">=")[0] for o in ordenes for a in o["args"]
                   if not a.startswith("-")}
        for nombre, _, _ in PAQUETES:
            assert nombre in pedidos, f"{nombre} no se instala en {maquina}"


# -- idempotencia: el if que evita reinstalar -------------------------------

def test_entorno_completo_no_genera_ordenes():
    for maquina in (LINUX, WINDOWS, MAC_ARM):
        assert plan(maquina, COMPLETO) == [], f"reinstala sin motivo en {maquina}"


def test_solo_se_pide_lo_que_falta():
    sin_peft = {k: v for k, v in COMPLETO.items() if k != "peft"}
    ordenes = plan(LINUX, sin_peft)
    pedidos = [a for o in ordenes for a in o["args"] if not a.startswith("-")]
    assert pedidos == [f"peft>=0.11,<1"]


def test_una_version_demasiado_nueva_se_corrige():
    futuro = {**COMPLETO, "transformers": "5.19.0"}
    pedidos = [a for o in plan(LINUX, futuro) for a in o["args"]]
    assert any(a.startswith("transformers") for a in pedidos)


def test_faiss_ausente_es_opcional_y_solo_rueda():
    sin_faiss = {k: v for k, v in COMPLETO.items() if k != "faiss-cpu"}
    ordenes = plan(MAC_ARM, sin_faiss)
    assert len(ordenes) == 1
    orden = ordenes[0]
    assert orden["obligatoria"] is False
    assert f"faiss-cpu>={FAISS_MIN},<2" in orden["args"]
    # Sin esto, en un Mac viejo pip intentaría compilar FAISS desde fuente.
    assert "--only-binary=:all:" in orden["args"]


def test_torch_siempre_es_obligatorio():
    for maquina in (LINUX, WINDOWS, MAC_ARM, MAC_INTEL):
        for orden in plan(maquina, TODO_NUEVO):
            if any("torch" in a for a in orden["args"]):
                assert orden["obligatoria"] is True


# -- avisos de versión de Python --------------------------------------------

def test_python_antiguo_se_rechaza():
    assert avisos_version_python((3, 9), mac_intel=False)


def test_python_probado_no_avisa():
    for menor in (10, 11, 12, 13):
        assert avisos_version_python((3, menor), mac_intel=False) == []


def test_python_mas_nuevo_que_lo_probado_avisa():
    assert avisos_version_python((3, 14), mac_intel=False)


def test_mac_intel_con_python_moderno_avisa_del_techo_de_torch():
    avisos = avisos_version_python((3, 12), mac_intel=True)
    assert any("3.11" in a for a in avisos)
    assert avisos_version_python((3, 11), mac_intel=True) == []


# -- el servidor MCP como proceso hijo --------------------------------------

def test_comando_servidor_es_portable():
    argv = comando_servidor()
    assert argv[0] == sys.executable, "en Windows no existe el ejecutable 'python3'"
    assert argv[1:3] == ["-X", "utf8"], "sin esto, el JSON con acentos rompe en Windows"
    assert Path(argv[3]).is_absolute() and Path(argv[3]).is_file()


def test_comando_servidor_falla_claro_si_no_existe():
    with pytest.raises(FileNotFoundError):
        comando_servidor("no_existe.py")


def test_entorno_hijo_fuerza_utf8():
    env = entorno_hijo()
    assert env["PYTHONUTF8"] == "1"
    assert env["PYTHONIOENCODING"] == "utf-8"


def test_el_respaldo_sin_faiss_da_el_mismo_resultado():
    """La rama de numpy del cuaderno 01 debe devolver lo mismo que FAISS.

    El cuaderno dice que el resultado no cambia cuando FAISS no está; esto lo
    comprueba sobre vectores normalizados, que es el caso que se usa allí
    (producto escalar = coseno). Se salta si FAISS no está instalado, que es
    precisamente el escenario en el que el respaldo entra en juego.
    """
    faiss = pytest.importorskip("faiss")
    import numpy as np

    generador = np.random.default_rng(0)
    E = generador.normal(size=(64, 32)).astype("float32")
    E /= np.linalg.norm(E, axis=1, keepdims=True)
    v = generador.normal(size=(1, 32)).astype("float32")
    v /= np.linalg.norm(v, axis=1, keepdims=True)

    indice = faiss.IndexFlatIP(E.shape[1])
    indice.add(E)
    sims_faiss, pos_faiss = indice.search(v, 3)

    puntuaciones = (E @ v.T).ravel()
    pos_numpy = np.argsort(-puntuaciones)[:3]
    sims_numpy = puntuaciones[pos_numpy]

    assert list(pos_numpy) == list(pos_faiss[0])
    assert np.allclose(sims_numpy, sims_faiss[0], atol=1e-6)


def test_requirements_dice_lo_mismo_que_entorno():
    """Los dos sitios donde viven las versiones no pueden divergir.

    `requirements.txt` es para quien se prepara el entorno a mano; `entorno.py`
    es lo que ejecutan los cuadernos. Si uno sube un techo y el otro no, un
    alumno acaba con una combinación que nadie ha probado.
    """
    texto = (raiz() / "requirements.txt").read_text(encoding="utf-8")
    declarado = {}
    for linea in texto.splitlines():
        linea = linea.strip()
        if not linea or linea.startswith("#"):
            continue
        nombre, _, rango = linea.partition(">=")
        minimo, _, maximo = rango.partition(",<")
        declarado[nombre] = (minimo, maximo)

    esperado = {n: (mi, ma) for n, mi, ma in PAQUETES}
    esperado["torch"] = (TORCH_MIN, "3")
    esperado["faiss-cpu"] = (FAISS_MIN, "2")

    assert declarado == esperado


def test_raiz_es_la_carpeta_de_la_demo():
    base = raiz()
    assert (base / "comun" / "config.py").is_file()
    assert (base / "mcp_demo" / "servidor_mcp.py").is_file()
    assert (base / "00_el_modelo.ipynb").is_file()
