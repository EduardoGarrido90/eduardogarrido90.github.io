"""Helper del profesor: convierte una lista de celdas en un .ipynb.

No lo necesita el alumno. Mantiene el notebook bajo control de versiones como
un .py legible, que es lo único que hace un diff decente.
"""

from __future__ import annotations

import json
from pathlib import Path

MD = "markdown"
PY = "code"

RAIZ = Path(__file__).resolve().parent.parent


def construir(celdas: list[tuple[str, str]], nombre: str) -> Path:
    """Escribe `nombre`.ipynb en demo_rapida/ a partir de (tipo, fuente)."""
    nb = {
        "cells": [],
        "metadata": {
            "kernelspec": {"display_name": "Python 3", "language": "python",
                           "name": "python3"},
            "language_info": {"name": "python", "version": "3.10"},
        },
        "nbformat": 4,
        "nbformat_minor": 5,
    }
    for tipo, fuente in celdas:
        fuente = fuente.strip("\n")
        lineas = [l + "\n" for l in fuente.split("\n")]
        if lineas:
            lineas[-1] = lineas[-1].rstrip("\n")
        celda = {"cell_type": tipo, "metadata": {}, "source": lineas}
        if tipo == PY:
            celda["execution_count"] = None
            celda["outputs"] = []
        nb["cells"].append(celda)

    destino = RAIZ / f"{nombre}.ipynb"
    destino.write_text(json.dumps(nb, ensure_ascii=False, indent=1) + "\n",
                       encoding="utf-8")
    print(f"  {destino.relative_to(RAIZ.parent)}  ({len(celdas)} celdas)")
    return destino
