"""Helper del profesor: convierte una lista de celdas en un .ipynb.

No lo necesita el alumno. Mantiene el notebook bajo control de versiones como
un .py legible, que es lo único que hace un diff decente.
"""

from __future__ import annotations

import json
from pathlib import Path

MD = "markdown"
PY = "code"

RAIZ = Path(__file__).resolve().parent.parent

# --------------------------------------------------------------------------
# El arranque, idéntico en los seis cuadernos.
# --------------------------------------------------------------------------
#
# Cada cuaderno se abre por su cuenta: un alumno puede empezar por el 02 sin
# haber tocado el 00. Por eso los seis llevan la misma primera celda, y por eso
# tiene que ser idempotente.
#
# Todo lo que distingue a Windows de macOS y de Linux vive en `comun/entorno.py`
# y no asoma aquí. El alumno ejecuta una celda y lee dos líneas.

ARRANQUE_MD = """\
## Antes de nada: preparar el ordenador

Ejecuta la celda de abajo antes que ninguna otra. Mira qué sistema operativo
tienes y qué hay ya instalado, y descarga **solo lo que falte**: funciona igual
en Windows, en macOS y en Linux, y no hace falta que instales nada a mano.

La primera vez tarda unos minutos, porque se baja PyTorch. Las siguientes
termina en un segundo. Se puede ejecutar tantas veces como quieras.

Si algo falla, cambia `instalar()` por `instalar(verboso=True)`, vuelve a
ejecutarla y enseña lo que imprima."""

ARRANQUE_PY = '''\
# Prepara el entorno: comprueba lo que ya tienes e instala únicamente lo que
# falte. Si ya está todo, no descarga nada.
import sys
from pathlib import Path

_aqui = Path.cwd()
_candidatas = [_aqui, *_aqui.parents,                       # lo normal
               *(f.parents[1] for f in _aqui.glob("*/comun/entorno.py")),
               *(f.parents[1] for f in _aqui.glob("*/*/comun/entorno.py"))]
_raiz = next((p for p in _candidatas
              if (p / "comun" / "entorno.py").is_file()), None)
if _raiz is None:
    raise RuntimeError(
        "No encuentro la carpeta 'comun'. Descomprime el zip entero y abre "
        "este cuaderno desde dentro de la carpeta demo_rapida.")
sys.path.insert(0, str(_raiz))

from comun.entorno import instalar, preparar

instalar()                 # ¿algo ha fallado? -> instalar(verboso=True)
_carpeta = preparar()      # deja las rutas del cuaderno listas'''


def celdas_arranque(con_titulo: bool = True) -> list[tuple[str, str]]:
    """Las celdas con las que empieza todo cuaderno de la demo.

    Args:
        con_titulo: si es False, devuelve solo la celda de código. El cuaderno
            00 ya trae su propia sección explicando qué hace falta.
    """
    if con_titulo:
        return [(MD, ARRANQUE_MD), (PY, ARRANQUE_PY)]
    return [(PY, ARRANQUE_PY)]


def construir(celdas: list[tuple[str, str]], nombre: str) -> Path:
    """Escribe `nombre`.ipynb en demo_rapida/ a partir de (tipo, fuente)."""
    nb = {
        "cells": [],
        "metadata": {
            "kernelspec": {"display_name": "Python 3", "language": "python",
                           "name": "python3"},
            "language_info": {"name": "python", "version": "3.10"},
        },
        "nbformat": 4,
        "nbformat_minor": 5,
    }
    for n, (tipo, fuente) in enumerate(celdas):
        fuente = fuente.strip("\n")
        lineas = [l + "\n" for l in fuente.split("\n")]
        if lineas:
            lineas[-1] = lineas[-1].rstrip("\n")
        # El identificador de celda es obligatorio desde nbformat 4.5. Uno
        # derivado de la posición mantiene el diff del .ipynb estable entre
        # regeneraciones, que es toda la gracia de construirlos desde un .py.
        celda = {"id": f"{nombre}-{n:03d}", "cell_type": tipo,
                 "metadata": {}, "source": lineas}
        if tipo == PY:
            celda["execution_count"] = None
            celda["outputs"] = []
        nb["cells"].append(celda)

    destino = RAIZ / f"{nombre}.ipynb"
    destino.write_text(json.dumps(nb, ensure_ascii=False, indent=1) + "\n",
                       encoding="utf-8")
    print(f"  {destino.relative_to(RAIZ.parent)}  ({len(celdas)} celdas)")
    return destino
