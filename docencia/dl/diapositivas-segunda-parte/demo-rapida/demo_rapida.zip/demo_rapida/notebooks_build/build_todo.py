#!/usr/bin/env python3
"""Regenera los seis cuadernos de la demo.

    cd demo_rapida
    python3 notebooks_build/build_todo.py
"""

from __future__ import annotations

import importlib
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from _nb import construir

MODULOS = ["build_00", "build_01", "build_02", "build_03", "build_04", "build_05"]
NOMBRES = ["00_el_modelo", "01_rag", "02_mcp", "03_sft", "04_lora", "05_rlhf"]


def main() -> None:
    for modulo, nombre in zip(MODULOS, NOMBRES):
        m = importlib.import_module(modulo)
        construir(m.CELDAS, nombre)
    print(f"\n{len(MODULOS)} cuadernos regenerados.")


if __name__ == "__main__":
    main()
