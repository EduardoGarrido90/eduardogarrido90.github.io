#!/usr/bin/env python3
"""¿Se resuelven todas las importaciones de los seis cuadernos?

    cd demo_rapida
    python3 notebooks_build/comprobar_importaciones.py

Herramienta del profesor, y de las baratas: lee los `.ipynb`, saca cada
`import` de primer nivel de cada celda de código y comprueba que el módulo
existe, con `sys.path` puesto como lo pone la primera celda del cuaderno. Dos
segundos, frente a los cincuenta minutos que cuesta descubrir lo mismo
ejecutando los seis.

Las importaciones dentro de un `try` no se comprueban: ahí es justo donde vive
lo opcional (FAISS, el SDK de MCP), que puede faltar sin romper nada.
"""

from __future__ import annotations

import ast
import importlib.util
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from comun.entorno import preparar, raiz  # noqa: E402

CUADERNOS = ["00_el_modelo", "01_rag", "02_mcp", "03_sft", "04_lora", "05_rlhf"]

# Lo que se importa dentro de un `if __name__`, de un `try` o de una función no
# cuenta, pero hay módulos que el cuaderno importa a sabiendas de que pueden no
# estar. Si alguno llegara a primer nivel, sería un fallo de diseño del
# cuaderno, no de la instalación del alumno.
OPCIONALES = {"faiss", "mcp", "bitsandbytes"}


def modulos_de(fuente: str) -> list[str]:
    """Módulos importados en el primer nivel de una celda.

    Devuelve la raíz del módulo: `from comun.config import X` -> `comun.config`,
    `import torch.nn as nn` -> `torch.nn`.
    """
    try:
        arbol = ast.parse(fuente)
    except SyntaxError:
        return []                      # celdas con magias de IPython (%pip, !)
    nombres = []
    for nodo in arbol.body:            # solo primer nivel: nada dentro de try
        if isinstance(nodo, ast.Import):
            nombres += [a.name for a in nodo.names]
        elif isinstance(nodo, ast.ImportFrom) and nodo.level == 0 and nodo.module:
            nombres.append(nodo.module)
    return nombres


def existe(modulo: str) -> bool:
    try:
        return importlib.util.find_spec(modulo) is not None
    except (ImportError, ValueError):
        return False


def main() -> int:
    preparar()                         # el mismo sys.path que la primera celda
    base = raiz()
    fallos: list[str] = []

    for nombre in CUADERNOS:
        ruta = base / f"{nombre}.ipynb"
        if not ruta.is_file():
            print(f"{nombre}: no existe el cuaderno")
            fallos.append(nombre)
            continue
        nb = json.loads(ruta.read_text(encoding="utf-8"))
        pedidos: set[str] = set()
        for celda in nb["cells"]:
            if celda["cell_type"] == "code":
                pedidos.update(modulos_de("".join(celda["source"])))

        rotos = sorted(m for m in pedidos
                       if m.split(".")[0] not in OPCIONALES and not existe(m))
        estado = "ok " if not rotos else "FALLA"
        print(f"   {estado} {nombre:16s} {len(pedidos)} módulos importados")
        for m in rotos:
            print(f"          no se resuelve: {m}")
            fallos.append(f"{nombre}: {m}")

    print()
    if fallos:
        print(f"{len(fallos)} importaciones sin resolver.")
        return 1
    print("Todas las importaciones de los seis cuadernos se resuelven.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
