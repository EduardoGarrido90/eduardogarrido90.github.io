# Demo — Slides interactivas en HTML (LÉEME)

**Objetivo.** Convertir un tema en un deck HTML autocontenido donde cada parámetro
se manipula en vivo (canvas), pensado para que el alumno explore, no solo lea.

**Slide asociada.** "Slides interactivas en HTML para que el alumno explore"
(bloque *Docencia*).

## Contenido

```
demo_slides_interactivas/
├── tema_fuente.md   # fuente del tema (Ridge/Lasso) para la skill
├── PROMPT.md
└── LEEME.md
```

## Prerrequisitos

- La skill `interactive-slides` vive en tu config global `~/.claude`.
- No hace falta Node ni CDN: el HTML es autocontenido (canvas + JS inline).

## Puesta en marcha

```bash
cd ~/taller_claude_code/demo_slides_interactivas
claude
```

Pega `PROMPT.md`. Al terminar, abre el `.html` generado en el navegador y mueve el
slider de $\lambda$ en directo.

## Plan B

Genera el HTML **la noche antes** y tenlo abierto en una pestaña: si la red falla en
directo, enseñas el resultado ya hecho y mueves los sliders igualmente (es local).
