# Fuente del tema — Regularización (Ridge y Lasso)

Material base para generar la slide interactiva. Nivel: grado de Business Analytics.

## Idea

Al ajustar un modelo lineal por mínimos cuadrados, coeficientes grandes provocan
sobreajuste. La regularización añade una penalización sobre el tamaño de los
coeficientes para mejorar la generalización fuera de muestra.

## Ridge (penalización L2)

$$\hat\beta_{\text{ridge}} = \arg\min_\beta \; \|y - X\beta\|_2^2 + \lambda \|\beta\|_2^2
= (X^\top X + \lambda I)^{-1} X^\top y.$$

- $\lambda = 0$: mínimos cuadrados ordinarios (máxima varianza).
- $\lambda \to \infty$: todos los coeficientes tienden a 0 (máximo sesgo).
- El parámetro $\lambda$ controla el compromiso **sesgo–varianza**.

## Lasso (penalización L1)

$$\hat\beta_{\text{lasso}} = \arg\min_\beta \; \|y - X\beta\|_2^2 + \lambda \|\beta\|_1.$$

A diferencia de Ridge, Lasso puede llevar coeficientes **exactamente a cero**:
hace selección de variables.

## Parámetros manipulables (para el canvas en vivo)

- $\lambda$: intensidad de la penalización (slider de 0 a 10).
- número de datos $n$ y ruido $\sigma$: cómo cambia el ajuste.
- Ridge vs. Lasso: conmutador que muestra el efecto sobre los coeficientes.

## Historia de negocio (framing docencia)

Predecir la demanda de una tienda con muchas variables correlacionadas: sin
regularizar, el modelo "memoriza" el histórico; con $\lambda$ bien elegido,
generaliza a semanas nuevas.
