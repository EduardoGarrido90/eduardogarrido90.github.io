# Demo — Slides interactivas en HTML

Ejecuta `claude` en esta carpeta y pega el prompt.

---

Usa la skill `interactive-slides` sobre `tema_fuente.md` (Regularización, Ridge y
Lasso). Genera un único deck HTML autocontenido, en estilo dignum-Comillas, para un
grado de Business Analytics: cada ecuación mostrada y cada símbolo explicado, y cada
parámetro manipulable en vivo con una simulación en canvas.

En particular, quiero un slider para $\lambda$ que actualice al instante la curva
ajustada y los coeficientes, y un conmutador Ridge/Lasso. Ábrelo al terminar.

---

> Momento "wow": el alumno mueve $\lambda$ y la figura responde en tiempo real; no
> es una slide que se lee, es una que se explora. Todo en un HTML sin dependencias.

## Cómo abrirlo

```bash
# Claude suele dejar el fichero .html en la carpeta; ábrelo en el navegador:
python3 -m http.server 8000   # y abre http://localhost:8000
```
