# Demo — Revisión adversarial de tu manuscrito (LÉEME)

**Objetivo.** Mostrar el patrón multi-agente aplicado a *peer review*: tres
revisores independientes leen el mismo `.tex` desde ángulos distintos y el líder
consolida un informe único por severidad.

**Slide asociada.** "Tres revisores adversariales leen tu manuscrito a la vez"
(bloque *Orquestar*).

## Contenido

```
demo_revision_paper_tuyo/
├── borrador.tex   # manuscrito de EJEMPLO con 5 debilidades plantadas
├── PROMPT.md
└── LEEME.md
```

`borrador.tex` es un manuscrito ficticio con fallos plantados (afirmación causal
excesiva, ausencia de baseline/test, cita no verificable, notación inconsistente,
*magic number*). En el directo, **cámbialo por tu paper real**.

## Prerrequisitos

- Los subagentes `methodology-reviewer-1`, `methodology-reviewer-2` y
  `methodology-reference-verifier` viven en tu config global `~/.claude`.
- El verificador de referencias necesita red para comprobar citas.

## Puesta en marcha

```bash
cd ~/taller_claude_code/demo_revision_paper_tuyo
claude
```

Pega `PROMPT.md`. Verás arrancar los tres revisores; al terminar, abre
`informe_revision.md` y repasa los hallazgos ordenados por severidad.

## Plan B

Si va lento, pide solo el revisor en orden canónico sobre `borrador.tex`: los
fallos plantados son vistosos y salen enseguida.
