# Demo — Tres revisores adversariales leen tu manuscrito

Ejecuta `claude` en esta carpeta y pega el prompt.

---

Revisa `borrador.tex` con tres revisores en paralelo, cada uno con su lente:

- uno en **orden canónico** (introducción → método → experimentos → conclusión),
- uno **empezando por los experimentos** (para pillar lo que el primero pasa por alto),
- un **verificador de referencias** que compruebe que cada cita existe y que la
  afirmación en el texto coincide con lo que el trabajo citado realmente demuestra.

Consolida todo en un único `informe_revision.md` ordenado por severidad, cada
hallazgo con severidad, localización (sección/línea), motivo y una sugerencia
concreta. No edites el manuscrito: solo quiero el informe.

---

> Momento "wow": tres *referees* independientes encuentran cosas distintas y el
> agente principal las funde en un informe único, como un panel de *area chairs*
> antes de enviar.

## Qué deberían cazar (fallos plantados en `borrador.tex`)

- La afirmación de que el método **"siempre supera"** a todo (sin evidencia).
- **Sin baseline ni test estadístico**: un solo problema sintético.
- La cita **`fictitious2023curvature`** no es verificable / probablemente no existe.
- Inconsistencia de notación **$\theta$ vs $\vartheta$**.
- El **$\kappa = 0.37$** "magic number" sin justificación ni ablación.

> En el directo, sustituye `borrador.tex` por **tu** paper real.
