# Demo — Bibliografía sin alucinaciones (LÉEME)

**Objetivo.** Mostrar la política de cero alucinaciones en acción: un verificador
**mecánico** compara cada campo del BibTeX contra la fuente descargada, y un panel
de agentes independientes repite la auditoría hasta que vuelve limpia.

**Slide asociada.** "Bibliografía sin alucinaciones: descargar, validar, repetir"
(bloque *Investigar*).

## Contenido

```
demo_bib/
├── referencias.bib   # EJEMPLO ficticio con 3 problemas plantados (NO CITAR)
├── PROMPT.md
└── LEEME.md
```

`referencias.bib` es bibliografía **ficticia y etiquetada** con fallos plantados
(año inconsistente, DOI que no resuelve, entrada mal formada). En el directo,
**cámbialo por tu `.bib` real** para ver la verificación contra fuentes reales.

## Prerrequisitos

- El subagente `methodology-reference-verifier` vive en tu config global `~/.claude`.
- Para verificar contra fuentes reales hace falta red (DOI/Crossref/arXiv/Scholar).
- `python3` disponible para el `validate_refs.py` que generará Claude.

## Puesta en marcha

```bash
cd ~/taller_claude_code/demo_bib
claude
```

Pega `PROMPT.md`. Verás a Claude escribir y ejecutar `validate_refs.py`, sacar la
tabla pass/fail y lanzar el verificador independiente.

## Plan B

Con las entradas ficticias, la parte de "descarga" fallará (no existen): es
esperado y **también es la lección** (referencias no verificables se bloquean). Si
quieres enseñar el caso "todo verde", trae tu `.bib` real ya validado y córrelo.
