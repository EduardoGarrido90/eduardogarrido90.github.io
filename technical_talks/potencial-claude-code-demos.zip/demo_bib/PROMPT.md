# Demo — Bibliografía sin alucinaciones: descargar, validar, repetir

Ejecuta `claude` en esta carpeta y pega el prompt.

---

Valida `referencias.bib` con mi política de cero alucinaciones. Escribe un
`validate_refs.py` que, para cada entrada, intente descargar la fuente (DOI /
Crossref / arXiv / Google Scholar) y compare campo a campo (autor, año, título,
venue, volumen, número, páginas, DOI) contra el BibTeX, normalizando acentos y
espacios. Cualquier discrepancia es un fallo duro con el par (obtenido, esperado).
Además, comprueba que cada `@article` tiene los campos obligatorios de su tipo.

Ejecuta el script, enséñame la tabla pass/fail por entrada y, cuando lo tengas
limpio, lanza un `methodology-reference-verifier` independiente que repita la
auditoría de cero. No corrijas los campos tú: solo señálalos.

---

> Momento "wow": la verificación es **mecánica** (descarga vs. BibTeX, no memoria) y
> un panel de agentes independientes la repite hasta que vuelve limpia. Es tu
> política de referencias, ejecutada.

## Qué debería detectar (problemas plantados en `referencias.bib`)

- `planted2021bo`: **año inconsistente** (campo 2021 vs. 2019 en el título).
- `ghost2020`: **DOI que no resuelve** y venue inexistente (no verificable).
- `incomplete2022`: `@article` **sin `pages` ni `volume`** (mal formado).

> En el directo, sustituye `referencias.bib` por **tu** `.bib` real.
