# Demo — Gmail vía MCP (LÉEME)

**Objetivo.** Mostrar el triaje de correo con un humano en el bucle: Claude etiqueta
lo urgente y prepara borradores; tú revisas y envías.

**Slide asociada.** "Gmail vía MCP: triaje de bandeja y borradores listos" (bloque *Conectar*).

## Prerrequisito (CRÍTICO — hacerlo ANTES de clase)

El connector de Gmail debe estar enlazado. Los connectors de claude.ai NO cargan si
`ANTHROPIC_API_KEY` está definida en tu entorno:

1. `unset ANTHROPIC_API_KEY` (o comenta la línea en `~/.bashrc`) y abre un terminal nuevo.
2. `claude` → `/login` con tu cuenta claude.ai (Pro/Max/Team).
3. En **claude.ai → Settings → Connectors**, activa **Gmail** y autoriza tu cuenta Google.
4. Verifica en Claude Code con `/mcp` que aparecen las herramientas de Gmail.

## Puesta en marcha

```bash
cd ~/taller_claude_code/demo_gmail
claude
```

Pega `PROMPT.md`. Empieza en modo `plan` o `default` para ver cada acción.

## Seguridad y Plan B

- El prompt prohíbe enviar y borrar: solo etiquetar y crear borradores. Aun así,
  **usa una cuenta de prueba** o revisa cada paso si demuestras sobre tu correo real.
- Plan B: enseña la figura `fig_gmail.pdf` del deck (bandeja + borrador de Claude) y
  narra el flujo si el connector no está listo.
- **Nunca** des de alta el connector en directo: hazlo el día antes.
