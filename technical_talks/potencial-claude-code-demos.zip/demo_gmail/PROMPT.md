# Demo — Gmail vía MCP: triaje de bandeja y borradores

Requiere el connector de Gmail activo (ver LEEME.md). Ejecuta `claude` y pega el prompt.

---

Con el connector de Gmail, revisa mi bandeja de entrada: identifica y etiqueta lo
urgente, y prepárame borradores de respuesta para los 2 o 3 hilos que más lo
necesiten. NO envíes nada ni borres nada: solo etiqueta y deja los borradores para
que yo los revise.

---

> Momento "wow": Claude clasifica los hilos y deja borradores redactados; tú solo
> revisas y pulsas enviar. La regla de oro: prepara, no envía.

## Seguridad

- El prompt pide explícitamente **no enviar ni borrar**: el humano aprueba lo que sale.
- Empieza en modo `default` o `plan` para ver cada acción antes de que ocurra.
