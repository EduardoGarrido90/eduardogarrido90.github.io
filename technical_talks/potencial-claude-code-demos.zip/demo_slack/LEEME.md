# Demo — Slack (LÉEME)

**Objetivo.** Mostrar que Claude Code trabaja sobre tu Slack real (leer un canal,
sintetizar, redactar), como una superficie más del mismo agente.

**Slide asociada.** "Slack: el agente vive donde ya trabaja tu equipo" (bloque *Conectar*).

## Prerrequisito (CRÍTICO — hacerlo ANTES de clase)

El connector de Slack debe estar enlazado. Recuerda que los connectors de claude.ai
NO cargan si `ANTHROPIC_API_KEY` está definida en tu entorno:

1. `unset ANTHROPIC_API_KEY` (o comenta la línea en `~/.bashrc`) y abre un terminal nuevo.
2. `claude` → `/login` con tu cuenta claude.ai (Pro/Max/Team).
3. En **claude.ai → Settings → Connectors**, activa **Slack** y autoriza tu workspace.
4. Verifica en Claude Code con `/mcp` que aparecen las herramientas de Slack.

Alternativa: la **app de Claude en Slack** (mencionas a `@Claude` en un canal); no
necesita el CLI, solo instalar la app en tu workspace.

## Puesta en marcha

```bash
cd ~/taller_claude_code/demo_slack
claude
```

Pega `PROMPT.md`.

## Plan B

- Si el connector no está listo: enseña la figura `fig_slack.pdf` del deck (mockup
  del canal con `@Claude`) y narra el flujo.
- **Nunca** des de alta el connector en directo (OAuth/latencia): hazlo el día antes.
