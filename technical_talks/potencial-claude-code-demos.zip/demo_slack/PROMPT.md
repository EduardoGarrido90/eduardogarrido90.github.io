# Demo — Slack: el agente donde trabaja tu equipo

Requiere el connector de Slack activo (ver LEEME.md). Ejecuta `claude` y pega el prompt.

---

Con el connector de Slack, lee los últimos mensajes del canal #curso-ia, resume los
3 temas principales que se están discutiendo y prepárame un borrador de resumen para
publicar. No publiques nada todavía: enséñame el borrador primero.

---

> Momento "wow": el mismo agente que usas en el terminal trabaja sobre tu Slack real:
> lee el canal, sintetiza y redacta, sin salir de la herramienta donde ya está tu equipo.

## Variante (desde la app de Claude en Slack)

Si usas la integración de Claude como app de Slack, la demo es aún más directa:
menciona a `@Claude` en un canal y pídele el resumen ahí mismo, desde el móvil.

```
@Claude resume los 3 preprints nuevos de arXiv de mi tema
```
