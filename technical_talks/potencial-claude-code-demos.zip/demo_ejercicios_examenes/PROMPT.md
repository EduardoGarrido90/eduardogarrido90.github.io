# Demo — Ejercicios y exámenes con rúbrica, solución y versión B

Ejecuta `claude` en esta carpeta y pega el prompt.

---

Usa la skill `/examenes` a partir de `temario.md` (Temas 3 y 4). Redáctame un examen
completo de 90 minutos y 10 puntos:

- 4 ítems con sus **puntos** y **tiempo estimado**, mezclando aplicación numérica y
  análisis/interpretación, cubriendo solo lo que aparece en el temario;
- una **rúbrica de corrección** por ítem y por punto;
- un **solucionario** completo, paso a paso;
- una **versión B** (convocatoria paralela) que examine lo mismo con otros números y
  la misma dificultad.

Deja cada artefacto en su fichero y valida que la versión B es equivalente en
dificultad a la A.

---

> Momento "wow": del *blueprint* del temario salen, en una pasada, examen + rúbrica
> + solucionario + convocatoria B, todo consistente y en tu formato.

## Variante (ejercicios de práctica)

Para ejercicios en vez de examen: `Usa /teaching sobre el Tema 3: genera tres
ejercicios con solución, dificultad y errores típicos, y un Kahoot de 8 preguntas.`
