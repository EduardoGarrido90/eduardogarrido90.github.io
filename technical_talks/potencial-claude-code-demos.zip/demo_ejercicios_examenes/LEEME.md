# Demo — Ejercicios y exámenes (LÉEME)

**Objetivo.** Mostrar la generación de evaluación a partir de la guía docente:
examen con puntos y tiempo, rúbrica, solucionario y una versión B equivalente
(y, como variante, ejercicios de práctica + Kahoot con `/teaching`).

**Slide asociada.** "Ejercicios y exámenes con rúbrica, solución y versión B"
(bloque *Docencia*).

## Contenido

```
demo_ejercicios_examenes/
├── temario.md   # extracto de guía docente (Temas 3 y 4)
├── PROMPT.md
└── LEEME.md
```

## Prerrequisitos

- Las skills `/examenes` (subagentes `exam-author`, `teaching-reviewer`, ...) y
  `/teaching` viven en tu config global `~/.claude`.
- Solo se examina lo que aparece en `temario.md`: la skill lo respeta.

## Puesta en marcha

```bash
cd ~/taller_claude_code/demo_ejercicios_examenes
claude
```

Pega `PROMPT.md`. Verás el planificador → autor → validadores en cadena; salen el
examen, la rúbrica, el solucionario y la versión B.

## Plan B

Genera de antemano el examen y su solucionario y tenlos a mano; si el directo va
lento, enséñalos y explica el *pipeline* con la figura `fig_teaching_pipeline` /
`fig_exam` del deck.
