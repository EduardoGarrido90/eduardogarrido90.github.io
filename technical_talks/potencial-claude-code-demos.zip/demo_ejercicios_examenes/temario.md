# Guía docente (extracto) — Métodos Cuantitativos para la Empresa

Asignatura de grado. Se examina SOLO lo impartido en esta lista.

## Tema 3 — Regresión y regularización

Objetivos (Bloom):
- **Comprender**: interpretar coeficientes de un modelo lineal.
- **Aplicar**: ajustar Ridge y Lasso, elegir $\lambda$ por validación cruzada.
- **Analizar**: diagnosticar sobreajuste con la curva sesgo–varianza.

Prerrequisitos: álgebra matricial básica, mínimos cuadrados.

## Tema 4 — Introducción a la decisión secuencial

Objetivos:
- **Comprender**: qué es un MDP (estados, acciones, recompensas, transición).
- **Aplicar**: calcular el valor óptimo de un MDP tabular pequeño.
- **Analizar**: interpretar la contracción de Bellman como punto fijo.

Prerrequisitos: probabilidad discreta, series geométricas.

## Formato de evaluación

- Examen de 90 minutos, 10 puntos.
- Mezcla de ítems de aplicación (numéricos) y de análisis (interpretación).
- Se exige rúbrica de corrección por ítem y solucionario completo.
- Dos convocatorias (A y B) de dificultad equivalente.
