# Demo — De una orden a un paper de principio a fin

Ejecuta `claude` en esta carpeta y pega el prompt. Es una demo **larga y deliberada**:
véndela como virtud (un pipeline de una decena de agentes trabajando por ti).

---

/bo

Propón una alternativa no publicada a Expected Improvement, verifica su novedad
contra la literatura, formaliza la teoría (regret o conjugación gaussiana),
impleméntala en GPyTorch/BoTorch con tests de referencia, corre una validación
por niveles con ≥10 semillas y estadística pareada, y redáctame el esqueleto del
manuscrito Q1 con figuras en TikZ y bibliografía verificada.

---

> Momento "wow": una sola orden encadena idea → literatura verificada → teoría →
> implementación con tests → experimentos → redacción → revisión adversarial. Cada
> etapa bloquea hasta quedar limpia.

## Alternativas más cortas (si el tiempo aprieta)

- Enseña solo la primera etapa: `/bo` hasta el shortlist de ideas del `bo-ideologue`
  y para ahí; el resto explícalo con la figura del deck (`fig_pipeline_paper`).
- O usa `/rl` o `/philosophy` si prefieres tu otro dominio.
