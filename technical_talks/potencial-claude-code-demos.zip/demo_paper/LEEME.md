# Demo — De una orden a un paper (LÉEME)

**Objetivo.** Mostrar que una *skill* (`/bo`, `/rl`, `/philosophy`) orquesta un
pipeline completo de subagentes especializados que produce el esqueleto de un
paper Q1: idea, literatura verificada, teoría, implementación con tests,
experimentos, redacción y revisión adversarial.

**Slide asociada.** "De una orden a un paper de principio a fin" (bloque *Orquestar*).

## Prerrequisitos

- La skill `/bo` (y sus subagentes `bo-ideologue`, `methodology-literature`,
  `bo-theorist`, `bo-implementer`, `bo-experimentalist`, `methodology-writer`,
  `methodology-reviewer-1/2`, `methodology-reference-verifier`) vive en tu config
  global `~/.claude`. No hay que construir nada en esta carpeta.
- Es una demo larga (minutos, no segundos) y consume tokens: usa Opus/Sonnet con
  criterio y ten claro dónde parar.

## Puesta en marcha

```bash
cd ~/taller_claude_code/demo_paper
claude
```

Pega `PROMPT.md`. Para el directo, lo habitual es arrancar el pipeline, enseñar el
*fan-out* de agentes y **cortar tras la primera o segunda etapa**, remitiendo a la
figura del deck para el resto.

## Plan B

Si la red falla o va lento: enseña la figura `fig_pipeline_paper.pdf` del deck y
narra las etapas; o ejecuta solo `/bo` hasta el shortlist de ideas (rápido y
vistoso) y para ahí.
