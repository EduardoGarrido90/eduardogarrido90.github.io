# Taller Claude Code — material

Carpeta de trabajo para el taller "El potencial de Claude Code y las terminales".

## Slides

- **`slides_definitivo.pdf`** — el deck definitivo (1 hora, 7 bloques).
- Fuente recompilable: `slides_definitivo.tex` + `make_figs.py` + `make_figs_def.py`
  y los recursos `figs/`, `logos/`, `icons/`, `assets/`.

```bash
# regenerar figuras y recompilar
python3 make_figs.py && python3 make_figs_def.py
pdflatex slides_definitivo.tex && pdflatex slides_definitivo.tex
```

## Demos (una carpeta por demo)

Cada carpeta trae `PROMPT.md` (lo que se pega en Claude) y `LEEME.md` (objetivo,
puesta en marcha y Plan B); algunas incluyen material de entrada.

| Carpeta | Qué muestra | Bloque del deck |
|---|---|---|
| `demo_paper/` | `/bo` orquesta un paper de extremo a extremo | Orquestar |
| `demo_revision_paper_tuyo/` | 3 revisores adversariales sobre tu manuscrito | Orquestar |
| `demo_bib/` | verificación de bibliografía sin alucinaciones | Investigar |
| `demo_ejercicios_examenes/` | examen + rúbrica + solución + versión B (`/examenes`) | Docencia |
| `demo_apuntes/` | temario + fuentes → apuntes con figuras (`/apuntes`) | Docencia |
| `demo_slides_interactivas/` | deck HTML interactivo (`interactive-slides`) | Docencia |
| `demo_slack/` | el agente sobre tu Slack (leer canal, resumir, redactar) | Conectar |
| `demo_gmail/` | triaje de bandeja y borradores con Gmail | Conectar |

## Prerrequisito común

Las skills y subagentes (`/bo`, `/examenes`, `/apuntes`, `interactive-slides`,
`paper_explained`, `methodology-reference-verifier`, ...) viven en tu config global
`~/.claude`; las carpetas de demo solo aportan el material de entrada y el prompt.

**Slack y Gmail (connectors).** `demo_slack` y `demo_gmail` necesitan los connectors
de claude.ai enlazados. Ojo: no cargan si `ANTHROPIC_API_KEY` está definida en tu
entorno (p. ej. en `~/.bashrc`). Para activarlos: `unset ANTHROPIC_API_KEY` →
`claude` → `/login` con tu cuenta claude.ai → activa Slack/Gmail en
claude.ai → Settings → Connectors → verifica con `/mcp`. Hazlo **antes** de clase.

## Antes del directo

- Comprueba que `claude` arranca y responde sin pedir login, y que hay red.
- Ensaya cada demo y **genera de antemano los archivos de Plan B** (un `.html`, un
  examen ya hecho, un informe de revisión) por si la red falla.
- Las demos que generan pipelines largos (`demo_paper`) consumen tokens: ten claro
  dónde parar y qué modelo usar (`/model`).
