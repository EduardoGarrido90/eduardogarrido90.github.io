# Fuente 2 — Lasso y selección de variables (nota de clase)

Nota didáctica de ejemplo (contenido estándar de libro).

El Lasso sustituye la penalización L2 por L1:
$$\min_\beta \|y - X\beta\|_2^2 + \lambda\|\beta\|_1.$$
La geometría de la bola L1 (con "picos" en los ejes) hace que la solución óptima
caiga a menudo sobre un eje, es decir, con algunos coeficientes **exactamente cero**.
Por eso el Lasso hace selección de variables automática, útil cuando se sospecha que
solo unas pocas variables importan.

No tiene solución cerrada; se resuelve con descenso por coordenadas o LARS. La
elección de $\lambda$ se hace por validación cruzada, igual que en Ridge.
