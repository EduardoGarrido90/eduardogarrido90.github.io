# Fuente 1 — Ridge regression (nota de clase)

Nota didáctica de ejemplo para alimentar los apuntes (contenido estándar de libro).

La regresión Ridge resuelve
$$\min_\beta \|y - X\beta\|_2^2 + \lambda\|\beta\|_2^2,$$
con solución cerrada $\hat\beta = (X^\top X + \lambda I)^{-1} X^\top y$. El término
$\lambda I$ hace la matriz siempre invertible (regulariza el mal condicionamiento),
incluso cuando $X^\top X$ es singular. Interpretación bayesiana: equivale a un prior
gaussiano $\beta \sim \mathcal{N}(0, \tau^2 I)$ con $\lambda = \sigma^2/\tau^2$.

El sesgo crece con $\lambda$ y la varianza decrece: el error de generalización tiene
un mínimo en un $\lambda$ intermedio (compromiso sesgo–varianza).
