# Temario — Tema 3: Regularización

Capítulo de apuntes a redactar. Audiencia: grado de Business Analytics.

Secciones previstas:
1. Motivación: por qué penalizar coeficientes (sobreajuste, generalización).
2. Ridge (L2): formulación, solución cerrada, límites $\lambda\to 0,\infty$.
3. Lasso (L1): selección de variables, por qué anula coeficientes.
4. Elección de $\lambda$ por validación cruzada.
5. Ejemplo resuelto: predicción de demanda con variables correlacionadas.

Requisitos de estilo (heredados de CLAUDE.md): prosa continua, sin listas;
definiciones enmarcadas; cada ecuación motivada antes y desempaquetada después;
figuras propias generadas con matplotlib.
