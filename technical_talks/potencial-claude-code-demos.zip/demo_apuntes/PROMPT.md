# Demo — /apuntes: de un temario y sus fuentes a apuntes con figuras

Ejecuta `claude` en esta carpeta y pega el prompt.

---

Usa la skill `/apuntes` para redactar el capítulo del Tema 3 (Regularización) a
partir de `temario.md` y de las fuentes de `fuentes/`. Quiero apuntes de asignatura
de verdad, no un resumen: prosa continua (sin listas), cada ecuación motivada antes
y desempaquetada después, una definición enmarcada para Ridge y otra para Lasso, un
ejemplo resuelto de predicción de demanda y al menos una figura propia
(sesgo–varianza) generada con matplotlib.

---

> Momento "wow": teje el temario con varias fuentes en un capítulo coherente y con
> figuras propias, siguiendo el estilo de mi CLAUDE.md. Es material que el alumno
> estudia, no un resumen plano.

## Prerrequisito

La skill `/apuntes` (subagentes `teaching-syllabus-planner`, `apuntes-writer`)
vive en tu config global `~/.claude`.
