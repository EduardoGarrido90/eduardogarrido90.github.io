# Demo — /apuntes (LÉEME)

**Objetivo.** Mostrar cómo `/apuntes` teje un temario y varias fuentes en un
capítulo de apuntes de asignatura: prosa continua, definiciones enmarcadas,
ejemplos resueltos y figuras propias (no un resumen).

**Slide asociada.** "/apuntes: de un temario y sus fuentes a apuntes con figuras"
(bloque *Docencia*).

## Contenido

```
demo_apuntes/
├── temario.md                 # el temario del Tema 3
├── fuentes/
│   ├── fuente1_ridge.md       # nota de clase (Ridge)
│   └── fuente2_lasso.md       # nota de clase (Lasso)
├── PROMPT.md
└── LEEME.md
```

## Prerrequisitos

- La skill `/apuntes` y sus subagentes viven en tu config global `~/.claude`.
- Para generar la figura hace falta `matplotlib` en el entorno.

## Puesta en marcha

```bash
cd ~/taller_claude_code/demo_apuntes
claude
```

Pega `PROMPT.md`. Verás el planificador de temario y el redactor en cadena; sale un
`.tex`/`.md` con el capítulo y su figura.

## Plan B

Genera el capítulo la noche antes y ábrelo compilado; si el directo va lento,
enséñalo y contrasta "apuntes vs. resumen" con la figura `fig_apuntes` del deck.
